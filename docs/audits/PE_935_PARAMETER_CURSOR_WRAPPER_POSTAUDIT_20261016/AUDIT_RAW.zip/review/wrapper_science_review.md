# Wrapper science review — records only

Run: PE_935_PARAMETER_CURSOR_UPSTREAM_WRAPPER_R1_20261016.

Allowed saved root: `D:\Eudoria_Reconstruction\99_Audits\PE_935_PARAMETER_CURSOR_UPSTREAM_WRAPPER_R1_20261016`. Governing contract and input copies: workspace outputs/PARAMETER_CURSOR_UPSTREAM_WRAPPER_PROMPT_R1_20261016. No package changes, original EXE reads, decoder/historical-tool executions, new callee bodies, caller census, repo, runtime, or network.

## Result

The central science claim remains supported **conditional on the declared entry and ABI models**. C is loaded into ESI from [entryESP+4] after two pushes. O is captured from entry ECX into EDI. On the read-success path, C/O/B cross exactly one opaque helper CALL at 0x00852A56. Conditional EBX/ESI/EDI preservation supports B==1 and C/O relay at CALL 0x00852A77 -> 0x00852750. CALL pushes return address 0x00852A7C; PUSH ESI is therefore at [parser_entryESP+4]. Registers and cursor contents are explicitly separated. No actual helper advancement, contents preservation, producer, medium, world role, class/tag semantics, or XYZ is established.

## Finding WRAP-SCI-01 (P2, narrow; does not retract the relay)

The report incorrectly rejects a semantically correct historical bypass return expression as decompiler noise.

Locations:

- `REPORT.md:23` — the historical expression `return (bVar2-1)&0xffffff00` is called "decompiler noise, superseded by the bytes".
- `EVIDENCE.json:184`, JSON pointer `/provenance_rows/3/finding` — the expression is declared "NOT in the bytes (decompiler noise)".
- `EVIDENCE.json:306`, pointer `/pseudo_vs_bytes_disclosures/0` — same semantic rejection.

Saved bytes actually compute the expression:

1. `0F B6 C3 @0x00852A64` — MOVZX EAX,BL, so EAX=u32(B).
2. `83 E8 01 @0x00852A67` — SUB EAX,1 modulo 2^32.
3. `74 08 @0x00852A6A` — B==1 enters the parser path; other values take bypass.
4. `32 C0 @0x00852A6E` — XOR AL,AL. This clears only the low byte of EAX, preserving EAX[31:8]. POP EDI/ESI/EBX and RET do not modify EAX.

Thus bypass returns the hardware register value `EAX = u32(B-1) & 0xFFFFFF00`. For B=0, EAX=0xFFFFFF00 while AL=0; for B=2..255, EAX=0. B=0 occurs even without crossing an opaque CALL on valid-fail and size-fail paths, so this is not dependent on a speculative callee effect or the saved-register assumption. The report's narrower statement AL=0 is correct; it does not contradict the pseudo expression. Do not infer a declared return type from this hardware fact. The correction is to preserve both facts and retract the claimed pseudo/byte disagreement. The B==1 gate and C/O relay remain supported.

## Guard, entry, and ABI checks

- valid-fail: MOV AL,[ESI+0x11] -> XOR BL,BL -> CMP AL,BL -> JE @0x00852A40 to gate, B=0; no data read or valid clear.
- size-fail: unsigned JA @0x00852A4B -> CMP AL,BL @0x00852A5D -> JE not taken for the stated valid!=0 path -> MOV [ESI+0x11],BL (=0). B remains default 0, bypass follows.
- read-success: u8 MOV BL,[ECX+EAX] @0x00852A4F; helper CALL then JMP @0x00852A5B to gate.
- Offset+1 and data+offset are explicitly 32-bit modulo; no OOB/no-wrap safety is claimed.
- B is zero-extended from BL to EAX, then compared through SUB/JE. It is not an AL preservation claim. The size-fail AL retest skips the helper path, so no old AL crosses the helper.
- Parser return EAX is locally passed through unchanged after the parser returns under the stack/ABI model; its epilogue contains only POP EDI/ESI/EBX and RET4.
- RET4 directly supports cleanup4; the contract/report separately frame exact parameter count as convention-model interpretation.
- Entry condition is expressly fixed at 0x00852A30, with no proof of arbitrary entries, callers, or complete CFG.
- No A/R inequality/equality or medium/world promotion was introduced. In-window cursor valid-field mutation is separated from pointer identity.

## Controls v3 — actual bounded scope

Read the full saved source `tools/t08_controls_v3.py`, EVIDENCE.machine_checkable_claims, controls/v3/CONTROL_SUMMARY.json, and all five BASE/C1/C2/C3/C4 result objects. No control tool was executed.

The saved records and code agree: BASE ACCEPTED exit0; C1-C4 REFUSED exit1 with NOT_INSTRUCTION_HEAD, ROLE_OR_SLOT_MISMATCH, UNJUSTIFIED_OPAQUE_PRESERVATION, and UNSUPPORTED_SOURCE_OR_WORLD_PROMOTION respectively. These are the four specific mutations required by the contract; reports expressly limit CONTROL_PASS to those mutations. C4 combines FILE+XYZ, and evaluation stops at FILE. It does not independently demonstrate XYZ, NETWORK, VFS, STATIC_BUILDING, or every promotion variant.

Do not infer global gate fail-closed correctness. The code checks the lists and assertions supplied by the claims record; it does not require complete list coverage, trusts `crosses_opaque_call`, accepts a supplied proof-key's existence without validating the proof object, and treats any truthy supplied `evidence` as evidence. Specific code anchors are lines36 (required top-level keys), 64 (supplied role list), 95-103 (proof-key lookup), 97 (supplied opaque-crossing flag), 114-119 (supplied source list/evidence, acceptance). These are limitations of the deliberately bounded qualifier, not demonstrated failures of the four actual required counter-trials. No broad verifier matrix was generated and no new control execution occurred.

## Checked / unchecked

Checked: contract, relevant preregistration models, EVIDENCE.json, REPORT.md, QC.json, HANDOFF and stage-gate references, authorized WRAPPER_PRIOR_PSEUDO copy, full saved 37-row roster, both saved 82-byte windows, and controls v3 source/results. Independently checked every roster row's offset, length, raw bytes, and VA against saved bytes: 37/37 match, no gaps/overlaps, final end82. Both windows byte-identical. Saved window SHA256 measured as `43134E71A4C84F7F06972F9EDC3C6BDC8A29A5FCBCF27E6D95252FE5B2D30B5C`. Recomputed all seven branch/CALL targets from recorded raw bytes: 7/7 match. Manually checked critical ModRM/SIB, widths, branches, CALL setup/stack arithmetic, B gate, and both epilogues.

Unchecked by this science subreview: original EXE identity/current contents; full input-pin inventory; full package manifest/persistence/process history; original tool execution truth; broad malformed-claims behavior; caller reachability; helper/parser bodies and actual effects; runtime; historical source medium, world objects, and XYZ. Other auditors may independently cover package/process matters.

HARD_STOP preserved. No next experiment authorized or prepared.
