# Wrapper process audit

Audited package: `D:/Eudoria_Reconstruction/99_Audits/PE_935_PARAMETER_CURSOR_UPSTREAM_WRAPPER_R1_20261016` and the declared authoring contract/inputs. No saved tool or decoder was executed. No source or package file was written.

## Audit-scope violation (must be disclosed)

An own input-identity verifier accidentally resolved absolute `inputs.path` values against the package root using Path(root)/absolute_path. On Windows this selects the absolute path. Its loop called `read_bytes()` on the original `Entropia.exe` for entries 0003, 0004, and 0005: **three unintended full original EXE reads, 3 x 8,015,872 B = 24,047,616 B**. This violated the explicit zero-original-read scope of this audit. No writes, decoder execution, or region analysis occurred. The parent was notified immediately when detected. Do not claim ZERO EXE READS for this audit. Do not use this verifier's original-identity comparisons as audit evidence. The new budget finding below was identified and sent to the parent *before* this mistake and is based on saved code and saved execution records only. These later audit reads are distinct from the original run's hidden pass.

Exact offending loop excerpt (executed as a PowerShell here-string piped into `C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe -B -`):

```python
for x in xlist:
    for f in x.get('inputs', []):
        p = r / f['path']
        if not p.exists() and f['path'].startswith('_incoming/'):
            p = r / 'attempts' / x['attempt_id'] / ('payload_input' + Path(f['path']).suffix)
        if p.is_file():
            raw = p.read_bytes()
            ok = (f.get('size_bytes') == len(raw) and
                  f.get('sha256') == hashlib.sha256(raw).hexdigest().upper())
            if not ok:
                print('inputdelta', x['attempt_id'], f['path'])
```

`xlist` was loaded from the whitelisted saved ledger, and `r` was the whitelisted audited root. The missing absolute-path rejection before `p.exists()/p.is_file()/p.read_bytes()` is the scope-escape defect. All three external EXE paths originated in saved ledger inputs, not from a deliberate new source selection. Further analysis was stopped without any further original reads.

## New P2: hidden extra full-EXE hash pass

The retained implementation of attempt 0003 performs two complete EXE reads while reporting only one. With closure this makes at least 3 passes against MAX_FULL_EXE_HASH_PASSES=2, and 24,051,876 original bytes against MAX_TOTAL_ORIGINAL_EXE_BYTES_READ=16,036,004.

- `tools/t02_hash_exe.py:31-37`: explicit full streaming read and counter.
- `tools/t02_hash_exe.py:45-48`: reports only that read's bytes under pass_index=1.
- `tools/t02_hash_exe.py:49`: calls `rc.file_identity(exe_rel_cfg)` to populate inputs metadata.
- `tools/run_common.py:88-91`: file_identity calls sha256_file.
- `tools/run_common.py:42-50`: sha256_file opens the same path and reads its entire contents again.
- `attempts/0003/entry.json` and ledger line 3: tool SHA matches the retained t02, status OK, input identity populated, result bytes_read=8015872/pass_index=1. The second call is not an unused/dead code path.
- `tools/t09_close.py:58-64`, attempt 0014: another complete streaming read, called pass 2.
- `SOURCE_READS.json.reads`, `BUDGET_USED.json.budgets.MAX_FULL_EXE_HASH_PASSES` and `.MAX_TOTAL_ORIGINAL_EXE_BYTES_READ`, REPORT budget table, and HANDOFF assert 2 passes / 16,036,004 B. They omit 8,015,872 B consumed by the helper.

This is separate from known F1 (CRT write translation). Metadata generation is still an original read; the contract explicitly counts all shared original reads/passes. This finding does not establish new science facts or authorize any additional read/repair.

## Known findings verified, not rediscovered

- F1 root cause is retained at `run_common.py:77-83`: os.open omits O_BINARY; returned output identities describe in-memory data. Known CRLF disk expansion explains every mismatching output/capture identity checked. No unexplained output identity mismatch was found after applying the documented in-memory CRLF reversal for comparison only.
- Saved header has 4099 B / SHA256 `2190840B26FDE4BA368326990246C24BA96F8E8C9C8603B9690A71FED69B0E29`. In-memory `replace(b'\r\n',b'\n')` yields the recorded 4096 B / `636B01A25A9DE410781805D67AE1149FA64DF3D26C5C4FDE7D2D9EBCABC5A5C0`. No corrected file was written.
- Both window files have 82 B / `43134E71A4C84F7F06972F9EDC3C6BDC8A29A5FCBCF27E6D95252FE5B2D30B5C`, and contain no CRLF expansion.
- Controls v1 -> v2 -> v3 follow the two disclosed defects: missing value for --child, then wrapper object instead of raw claims. The predicate is unchanged by these repairs; first corrected versions and complete previous outputs remain under distinct names.
- F2 exhausted 2/2 rounds is disclosed. No evidence of another post-round code/report correction was found; remaining materializations are planned first writes and F1 remains physically uncorrected.
- Directly authored STAGE_ACCEPTANCE_GATES.csv, with no serializer timestamp, is disclosed.

## Minor P3

`QC.json.findings[F1].affected_artifacts.window_buffers` contains a 63-hex-digit truncated digest ending `...D30B5`; the actual and other authoritative references are 64 hex digits ending `...D30B5C`. This is a documentation typo, not a buffer difference or another F1 effect.

## Verified process evidence

- 19 ledger entries; 38414 B; SHA256 `424AFCF817F8C62A695B7E6CCC3A958BC0A49C869B070E8ED793EC8ACF0EA97E`.
- All 19 saved prefix size/hash claims match current physical ledger prefixes. All 19 `attempts/NNNN/entry.json` objects equal their ledger objects.
- Every listed output and stdout/stderr capture exists, matching its logical recorded identity directly or through F1's documented reversal; no missing output or unexplained delta was found.
- All 19 recorded top-level tool digests match retained source files. All 19 config size/hash identities match retained RUN_CONFIG.
- All attempts have separate entry/stdout/stderr, and the eight document payloads remain under their corresponding attempt directories.
- Final physical census is 125 files / 566173 B, within 128 files / 8 MiB. Manifest has the latest mtime among package files; no later package write is evident from saved mtimes.
- Serializer timestamps and attempt start/end fields are measured in retained code; no agent-memory timestamp replacement was found.
- Full code read: run_common, t00, t02, t09, t10; complete diffs v1->v2->v3; targeted reads of t03/t04/t05/t06/t07 input/output paths.

## Limits

- Actual historical preflight session commands and every semantic content-read claim for all twelve inputs are not externally witnessed by this audit.
- No decoder was run; no scientific semantic re-derivation beyond reading saved paths and budgets.
- Full per-attempt actual helper-code identity is not recorded: every attempt binds the main tool SHA, but imports run_common without a per-attempt helper SHA. Main tool sizes are also absent from attempt entries (available in the final census). These are narrower provenance limitations; no helper mutation is asserted.
- t09/t10 inputs arrays are empty despite their recorded filesystem reads; results/config provide partial provenance. No additional read count beyond the explicit hidden t02 pass is inferred from this omission.
- The accidental original reads above invalidate the requested zero-original-read process property of this audit itself. The budget analysis remains reproducible from saved files without such reads.
