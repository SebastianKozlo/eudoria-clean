# PE935 — poprzednia krawędź kursora: wrapper FUN_00852A30

RUN_ID = PE_935_PARAMETER_CURSOR_UPSTREAM_WRAPPER_R1_20261016
RUN_CLASS = BOUNDED_STATIC_CURSOR_RELAY_MICRORUN
ERA = PCG_9_3_5
EVIDENCE_COMMIT = 3fbe93eec04759395223e6677b5040273d29222a
BASE_SHA = NOT_APPLICABLE_PRIVATE_RUN_NO_GIT_WRITE
AUTHORING_STATUS = PREPARED_NOT_EXECUTED

Ten kontrakt przygotowuje następny krok poszukiwania źródła historycznych lokalizacji. Jego wykonanie wymaga osobnego polecenia człowieka wskazującego ten konkretny plik, SIZE_BYTES/SHA256 oraz zakres. START_OPENCODE.txt zawiera gotowe takie polecenie. Przygotowanie pakietu nie oznacza wykonania science.

## 1. Jedno pytanie i oczekiwany postęp

**W zapisanym zakresie FUN_00852A30: czy wartość przekazywana do FUN_00852750 jest tym samym kursorem C, który wrapper otrzymał na wejściu; jaki receiver O jest przekazywany i jaka dokładna lokalna bramka odczytanego bajtu dopuszcza ten transfer?**

Sprawdź wyłącznie poprzednią krawędź ustalonego szwu. Wynik ma odróżnić przekazywanie istniejącego kursora od jego konstrukcji lub wypełnienia. Nawet potwierdzony relay nie ustanawia źródła FILE/NETWORK/VFS, statycznego budynku, klucza instancji ani XYZ.

Nowa wskazówka nawigacyjna to `inputs/WRAPPER_PRIOR_PSEUDO.txt`, wyeksportowana byte-identycznie z obiektu Git wskazanego w INPUT_PINS. Stary analyzer podaje body0x00852A30–0x00852A81, czyli okno [0x00852A30,0x00852A82), **0x52=82 B**. Pseudokod sugeruje odczyt jednego bajtu z data+offset, bramkę wartości i przekazanie argumentu do FUN_00852750. To NAVIGATION_ONLY, bez świeżego potwierdzenia bajtów, sygnatury, formy transferu ani roli bajtu.

Nie wykonuj szerokiego census callerów, vtable, xrefów ani tekstu EXE. Nie wybieraj arbitralnego początku site−N. Ten run ma z góry jeden konkretny zakres. Start jest prerejestrowanym anchorem z historycznego analyzera: deklaruj założenie wejścia właśnie pod0x00852A30. Zgoda decoderów od tego startu nie dowodzi automatycznie wszystkich wejść ani kompletnego CFG programu.

## 2. Role, dokładne ścieżki i autoryzacja

PE-MASTER prowadzi run i bezpośrednio przydziela jego wykonanie `pe-reconstruction`. Wykonawca może napisać małe prywatne narzędzia wyłącznie w nowym OUTPUT_ROOT; nie zmienia narzędzi projektu. Nie dispatchuje dalszych agentów. PE-MASTER może zlecić jednemu `pe-master-auditor` odrębne QC po zapisanych dowodach, bez odczytu EXE i bez kolejnego poziomu delegacji. W razie braku świeżego kontekstu uczciwie użyj SELF_REVIEW_WITH_LIMITATIONS.

AUTHORING_ROOT:
`C:\Users\User\Documents\Codex\2026-10-13\files-pasted-by-the-user-wszystko\outputs\PARAMETER_CURSOR_UPSTREAM_WRAPPER_PROMPT_R1_20261016`

INPUT_PINS:
`C:\Users\User\Documents\Codex\2026-10-13\files-pasted-by-the-user-wszystko\outputs\PARAMETER_CURSOR_UPSTREAM_WRAPPER_PROMPT_R1_20261016\INPUT_PINS.json`
INPUT_PINS_SIZE_BYTES = 6186
INPUT_PINS_SHA256 = E6F46702F9BE6821282C40B1F1C3479E523CFDF0BB9384D547C32D8C08BE3B65

OUTPUT_ROOT:
`D:\Eudoria_Reconstruction\99_Audits\PE_935_PARAMETER_CURSOR_UPSTREAM_WRAPPER_R1_20261016`

FINAL_REPORT_PATH:
`D:\Eudoria_Reconstruction\99_Audits\PE_935_PARAMETER_CURSOR_UPSTREAM_WRAPPER_R1_20261016\REPORT.md`

RUN_CONFIG_PATH:
`D:\Eudoria_Reconstruction\99_Audits\PE_935_PARAMETER_CURSOR_UPSTREAM_WRAPPER_R1_20261016\RUN_CONFIG.json`

AUTHORING_ROOT i wszystkie inputs są READ_ONLY. OUTPUT_ROOT nie jest podkatalogiem AUTHORING_ROOT. Utwórz go atomowo dopiero po wymaganym preflight; istniejący root oznacza BLOCKED_PREFLIGHT, bez nadpisania, usuwania, relokacji lub wymyślania innego RUN_ID. Nie zmieniaj gotowych pakietów poprzedników. Ten prywatny run nie wymaga zmiany Git HEAD, branch, commit, pull/fetch ani push. EVIDENCE_COMMIT identyfikuje wyłącznie wyeksportowane dowody historyczne.

## 3. Wejścia i obowiązująca interpretacja historii

Przeczytaj i zweryfikuj wszystkie **12/12** plików z INPUT_PINS; nie podążaj za ich odsyłaczami do innych runów. Role i rzeczywiste SIZE/SHA są w pinach. Hash nie zastępuje odczytu treści. Poza allowlistą nie otwieraj nowych zapisanych źródeł, repo, SDK, archiwów ani danych świata. Dopuszczona biblioteka x86 jest jedynym wykonywalnym kodem spośród inputs; pozostałe źródła czyta się jako dane.

Stan poprzednika nie jest zerowany: PARAMETER_RECORD_INGRESS_R1 ma terminal PARTIAL i potwierdzony warunkowo rdzeń szwu; FULL_PROCESS_COMPLIANCE=NOT_ESTABLISHED. Otwarty P2-1, DISCLOSURE-M1 oraz postaudytowe PRI-PA-01/02/03 pozostają w historii. Nie naprawiaj ich plików i nie odtwarzaj utraconych wyników. Nowy licznik rund dotyczy wyłącznie nowego runu, bez retroaktywnego efektu.

Stosuj już teraz poprawną interpretację poprzedniego ingress, bez ponownego otwierania jego body:

- valid=0 na loop-head: JE@0x00852818→0x008528CF, wyjście bez inicjalizacji; nie K=0;
- dopiero size-fail przy valid!=0: JA@0x00852827→0x00852839, K=0 i clear valid;
- loop back-edge to JB@0x008528C9→0x00852813; JMP@0x00852900→0x008528D2 prowadzi do epilogu;
- RET4 bezpośrednio dowodzi cleanup4 B; liczba parametrów i thiscall wymagają modelu konwencji;
- A, R, V oraz C/O są różnymi symbolami. Różne lineage nie dowodzą nierówności wartości, a lineage przez opaque CALL wymaga jawnych przesłanek;
- dotychczasowe 31 celów bezpośrednich +1 forma pośrednia nie oznaczają32 rozpoznanych callees;
- cursor relay i pamięć jako bezpośrednie źródło nie ustanawiają nośnika historycznego ani pozycji świata.

W kopiach wejść dawne PENDING i błędne zdania pozostają historyczne. Nowszy postaudyt jest obowiązującą interpretacją w zakresie jego ustaleń; nie udawaj, że poprzednik został poprawiony lub uzyskał PASS.

## 4. Preflight bez oryginalnych odczytów

1. Zmierz SIZE/SHA niniejszego kontraktu względem polecenia człowieka, INPUT_PINS oraz każdej kopii. Sprawdź dokładny zbiór inputs: bez extra, braków, duplikatów, symlink escape. Nie dopasowuj pinów.
2. Sprawdź OUTPUT_ROOT ABSENT i fizyczną lokalizację VM. Nowy audit root leży poza znanym checkoutem D:\Eudoria_Reconstruction\12_WebGame\eudoria-clean. Sprawdź również istniejących przodków OUTPUT_ROOT pod kątem .git: gdyby root znalazł się wewnątrz checkoutu, wynik to BLOCKED_PREFLIGHT, bez wyjątku dla ignored/untracked audit files. Sam ten test lokalizacji nie upoważnia do czytania repo. Nie zapisuj wyników na hoście Hyper-V ani na przekierowanym dysku RDP. Po potwierdzeniu pinów oraz ABSENT utwórz nowy root atomowo; zserializuj realny preflight. Jeśli któryś warunek zablokuje utworzenie, zwróć BLOCKED w wiadomości, nie twórz alternatywnego katalogu.
3. Zapisz RUN_CONFIG.json z dokładnym OUTPUT_ROOT i ścieżkami AUTHORING_ROOT/inputs. Wszystkie własne narzędzia muszą czytać root z tego configu, przyjmować jawny nowy output attempt-dir i odmawiać wyjścia poza OUTPUT_ROOT. Nie buduj rootu z cwd, katalogu kontraktu ani `Path(__file__).parent.parent`.
4. Przed pierwszym odczytem EXE sprawdź oba przypięte decodery. PATH_A: GNU objdump2.44 przez WSL, `/usr/bin/objdump`, SHA256 `96AFB8521834982D0E711B5D6E9785252BF82129FB0106B93A6BD54D83FAE11F`; zachowaj rzeczywiste argv, wersję, hash i exit. PATH_B: inputs/x86dec_pinned.py, 27188 B / `C8E8470EFD762F66FF20369B2F656694C635131261F4D611DCA9C504E2B90B95`; import read-only, bez main i pycache. Nie używaj syntetycznego decode jako testu dostępności.
5. Brak lub mismatch narzędzia: BLOCKED_TOOLING i zero science. Bez instalacji, alternatywnego dekodera lub poprawiania biblioteki. Autor tego prompta nie mierzył dzisiejszej dostępności narzędzi ani EXE.
6. Zapisz raz PREREGISTRATION.json przed pierwszym hashem/odczytem oryginału: pytanie, zakres, entry assumption, modele ABI, warianty, limity, cztery kontrole i terminale. Nie prognozuj liczby instrukcji/callsite’ów. Nie przepisuj prerejestracji po zobaczeniu wyników.

## 5. Oryginał, mapowanie i twarde budżety całego runu

Jedyny oryginał do odczytu po preflight:
`D:\Eudoria_Reconstruction\pcg_install\Entropia.exe`
SIZE_BYTES = 8015872
SHA256 = E7785430E81DFFE648CE8F5312414B17BC9FCE61389689A22F753765D5280F31

```ini
SUBJECT = FUN_00852A30
WINDOW_START_VA = 0x00852A30
WINDOW_END_EXCLUSIVE_VA = 0x00852A82
WINDOW_SIZE_BYTES = 82
DOWNSTREAM_EXPECTED_TARGET_VA = 0x00852750
NEW_FUNCTION_BODIES = 1
NEW_CALLEE_BODIES = 0
MAX_WRAPPER_HOPS = 0
MAX_UNIQUE_INSTRUCTION_STARTS = 96
MAX_ACCOUNTED_CALLSITE_UNITS = 6
MAX_SYMBOLIC_STATES = 8
MAX_PROVENANCE_ROWS = 12
MAX_FULL_EXE_HASH_PASSES = 2
MAX_HEADER_READS = 1
MAX_HEADER_BYTES = 4096
MAX_ORIGINAL_CODE_WINDOW_READS = 2
MAX_ORIGINAL_CODE_BYTES = 164
MAX_TOTAL_ORIGINAL_EXE_BYTES_READ = 16036004
MAX_PATH_A_FULL_SWEEPS = 2
MAX_PATH_B_DECODE_APPLICATIONS = 192
MAX_SYNTHETIC_X86_DECODE_APPLICATIONS = 0
ADDITIONAL_SAVED_INPUT_FILES = 0
MAX_ERROR_CORRECTION_ROUNDS = 2
MAX_OWN_FILES = 128
MAX_OWN_PACKAGE_BYTES = 8388608
```

`16036004 = 2×8015872 +4096 +2×82`. Liczniki są wspólne dla executora, poprawek, QC i materializacji. Wcześniejsze limity poprzednika nie dają dodatkowych odczytów w tym runie. Wszystkie replays countują się ponownie do sweeps/applications, choć nie tworzą nowych unique instruction starts.

Pierwszy pełny SHA wykonaj streamingowo przed content reads. Następnie jeden odczyt PE32 ≤4096 B: sprawdź machine, magic, ImageBase, unikalne RAW-backed pokrycie całego przedziału, bounds, overlap/BSS/wraparound. Offset wyprowadź maszynowo, nie kopiuj oczekiwanego wyniku z hexu. Critical mismatch zatrzymuje science bez zmiany pinów/okna.

Odczytaj dokładnie dwa82-B bufory w dozwolonym przedziale i zachowaj je osobno, przed analizą. Sprawdź zgodność. Awaria harnessu nie daje trzeciego odczytu; nie wykonuj prefix reads, odczytu za RET ani skanu sąsiedztwa. Bufory oryginału w pakiecie: wyłącznie jeden nagłówek i dwa okna. Nie zapisuj całego EXE. Drugi pełny SHA przy zamknięciu rozpoczętego science; przy krytycznej zmianie tożsamości zakończ negatywnie, nie kontynuuj analizy.

Budżety instruction/callsite/state generuj z faktycznych list. Callsite unit to unikalne(VA,rola), z każdym wykorzystanym opaque boundary i ewentualnym tail-transferem. Nie myl ich z liczbą różnych targetów. Nie rozwijaj pętli. Wyczerpanie oznacza PARTIAL/NOT_ESTABLISHED_WITHIN_BOUND, bez rozszerzenia scope.

## 6. Dekodowanie i kwalifikacja transferu

A i B startują niezależnie na tych samych zapisanych82 B od offset0. Nie karm B głowicami A. PATH_A czyta zapisany bufor przez `/mnt/d/...` bez kopiowania do WSL `/tmp` lub home. PATH_B importuje przypiętą bibliotekę przez jawny path; Python-B/PYTHONDONTWRITEBYTECODE. Nie odpalaj historycznych skryptów z pakietów poprzedników.

Porównaj pełne roster/start/length/raw oraz rzeczywiste branch/call/jmp cele. Obsłuż continuation lines PATH_A jako bytes poprzedniej instrukcji, nie nowe głowice. Emituj jeden wiersz na VA; sprawdzaj duplikaty przed mapowaniem; puste wejścia nie mogą otrzymać PASS. Brak wymaganego pola nie jest jawnym null, zerem ani zgodnością. Error/unsupported nie jest udaną detekcją.

Znana biblioteka może nie zapisywać imm/target dla unprefixed E8/E9. Dopuszczona jest jawna rekomputacja `target=(VA+length+signed_rel) mod2^32` z własnych raw bytes rozpoznanej instrukcji; oznacz `TARGET_SOURCE=ARITHMETIC_FROM_RECORDED_RAW`. Nie przedstawiaj tego jako dwóch niezależnych porównań pełnej semantyki operandów. Nie dopisuj opcode, nie rozszerzaj ogólnie decoderów/comparatora ani QC platformy.

W krytycznych wierszach sprawdź ręcznie lub małym jawnie ograniczonym checkiem encodingu: rejestry PUSH/MOV, ModRM/SIB/disp, szerokość odczytu bajtu, TEST/CMP/sub/dec, kierunek branch, cleanup i formę transferu. Wykazuj dokładnie te operandy, które są reprezentowane/sprawdzone. Zgodne bytes nie wystarczają do ogłoszenia zgodności nieprzetestowanych pól.

Nie narzucaj formy CALL: pseudo może ukrywać JMP/tail-transfer. Znajdź actual transfer do0x00852750, zapisz jego VA, raw, głowicę osiąganą od zadanego entry i target z arytmetyki. Przy JMP przeprowadź poprawne mapowanie istniejącego argumentu stosowego na `[parser_entryESP+4]`; przy CALL rozlicz także push adresu powrotu. Nie uznawaj rejestru z adresem kodu za C lub O.

Nie kończ automatycznie na pierwszym RET; obejmij wszystkie82 B i warianty mieszczące się w oknie. Cele poza oknem wpisz jako OPEN_EDGE bez odczytu. Gdy nie da się zakwalifikować transferu z tego entry w limicie, oddaj NOT_ESTABLISHED_WITHIN_BOUND lub NOT_QUALIFIED_TOOL_LIMIT. Nie otwieraj Ghidry ani kolejnego body dla ratowania wyniku.

## 7. Analiza jednego mostu C/O i bramki bajtu

Nazwij osobno:

- `C_wrapper_entry` — wartość wejściowego slotu/registra, z dokładnym entryESP offset;
- `C_at_read`, `C_at_opaque_helper`, `C_at_parser` — wartości na tych etapach, bez automatycznego utożsamienia;
- `O_wrapper_entry`, `O_at_parser` — potencjalny ECX receiver, bez nazwy klasy lub world role;
- `B_read` — bajt faktycznie odczytany z bufora lub wartość podstawiona na konkretnej gałęzi;
- `P_code_target` — adres transferu, osobno od pointerów danych.

W maksymalnie12 wierszach provenance udokumentuj VA/raw/operand/warunek/status/przesłanki/falsifier:

1. Prolog i równanie stosu: skąd wrapper pobiera C i czy zachowuje wejściowy O. Nie wyprowadzaj liczby wszystkich parametrów wyłącznie z RET imm.
2. Źródło i szerokość odczytu B: data, offset, size, valid; wskaż rzeczywiste operacje, nie deklarowaną strukturę z pseudo.
3. Osobne ścieżki: valid-fail, size-fail i read-success. Zapisz dokładnie, czy każda zeruje bajt/rejestr, czy clearuje valid i dokąd idzie. Nie powtarzaj błędnego wspólnego „guards fail→zero”.
4. Arytmetyka offset+1 i bramki B: faktyczna szerokość, unsigned/signed, modulo256 lub2^32 według encodingu. Nie ustanawiaj ogólnej OOB safety/no-wrap. Dopuszczona wartość B nie staje się automatycznie typem rekordu, wersją, tagiem budynku, pozycją lub modelem.
5. Opaque helper wyglądający na advance(1): actual receiver/args/target i przechowane rejestry. **Rzeczywisty przyrost offsetu i modyfikacje pamięci przez helper pozostają NOT_ESTABLISHED.** Jego body jest zamknięte.
6. Wartość B użyta po helperze: sprawdź, czy jest zachowana w odpowiednim rejestrze/stack slot; opaque CALL może zmienić volatile EAX/AL. Nie przenoś wartości „sprzed CALL” do RET/warunku bez proof lub jawnego założenia.
7. Actual transfer do0x00852750: gdzie C i O trafiają, jaka lokalna bramka go dopuszcza i co dzieje się na bypass. Mapuj sloty i pointer levels, nie same nazwy rejestrów.
8. Czy to relay, local construction, field load, global load, opaque return lub NOT_ESTABLISHED. Wniosek musi wynikać z zaobserwowanych operacji. Przekazanie C nie dowodzi jego utworzenia/wypełnienia.

Jawne modele: `CONDITIONAL_ON_ENTRY_MODEL` dla zadanego startu oraz, gdy potrzebne, `CONDITIONAL_ON_ABI_MODEL` dla preserved registers i cleanup. Wypisz każde opaque przejście między load a use. Oddziel preservation pointera w rejestrze od preservation zawartości kursora w pamięci. Sam zapis na stosie jest obserwacją; odzyskanie tej samej wartości później wymaga jawnych przesłanek frame/cleanup/memory, nie automatycznej gwarancji.

Oddziel też model bez tych założeń: właściwe identity/preservation pozostają NOT_ESTABLISHED. Nie używaj typowych /GS/thiscall kształtów jako dowodu zachowania EAX/AL przez konkretny callee. Nie otwieraj callees dla potwierdzenia ABI.

## 8. Cztery małe kontrole i QC

Kontrole dotyczą kopii claims i wyników rzeczywistego JSON/CLI loadera. Nie zmieniaj oryginalnych buforów, nie wykonuj syntetycznego x86 decode, nie buduj uniwersalnego semantic verifiera.

- C1: ustaw transfer-site na bajt wewnątrz faktycznej instrukcji; oczekiwana odmowa z reason `NOT_INSTRUCTION_HEAD`.
- C2: zamień opis C i O/receivera/argumentu wbrew faktycznie ustalonym operandom i slotom; oczekiwana odmowa `ROLE_OR_SLOT_MISMATCH`.
- C3: awansuj preservation po opaque helperze do bezwarunkowego CONFIRMED bez proof i bez modelu ABI; oczekiwana odmowa `UNJUSTIFIED_OPAQUE_PRESERVATION`.
- C4: wpisz FILE/NETWORK/VFS/STATIC_BUILDING/XYZ jako ustalone źródło/rolę bez odrębnego dowodu; oczekiwana odmowa `UNSUPPORTED_SOURCE_OR_WORLD_PROMOTION`.

Przypadek bazowy musi przejść ten sam właściwy predykat wyłącznie na poziomie rzeczywiście wykazanego modelu. CONTROL_PASS oznacza wymaganą odmowę dla tej konkretnej mutacji; nie obalenie rzeczywistej hipotezy ani ogólną poprawność verifiera. Jeśli brak anchoru lub wykazanej roli, kontrola zależna jest NOT_PERFORMED z powodem. Nie generuj odmów na podstawie przypadkowego parse ERROR. Wymagaj właściwego reason i niezerowego exit. Osobno zlicz control cases, base/mutant outcomes, procesowe próby oraz ponowienia; nie wymuszaj jednej sumy.

Odrębne QC sprawdza zapisane bufory/roster, wszystkie istotne operandy i gałęzie, mapowanie C/O, tag vs semantyka, ABI, counterexamples, rzeczywiste limity i kompletność historii prób. Świeży recenzent nie czyta EXE, nie uruchamia nowych decoderów i nie naprawia plików. Hash-check i independent byte arithmetic na istniejących records nie są świeżym decoder sweep. Uczciwie podaj QC_ORIGIN.

## 9. Proces: brak nadpisania, rzeczywiste czasy, jeden licznik korekt

Każda zapisana własna wersja narzędzia i każdy output próby są niezmienne. Narzędzia: wersjonowane nazwy; próby: świeże `attempts/0001/`, `0002/` itd. Każda ma pełny actual code/input/config SIZE/SHA, argv, stdout/stderr, exit, pełny result object i czasy lub null+UNKNOWN. Output-dir tworzy się atomowo; istniejący plik jest odmową, nie zapisem w trybie w. Nie uruchamiaj generatora ponownie na tej samej nazwie wyniku. Re-QC zachowuje pełne pierwsze per-file wyniki, nie tylko summary.

Jedyny dopisywany plik to ATTEMPT_LOG.jsonl; bez edycji/usuwania starych linii. Przy append odnotuj rozmiar i SHA prefixu sprzed append. To dowód zgodności prefixu, nie zewnętrzne świadectwo czasu.

Timestamp start/end wykonania pochodzi bezpośrednio z użytego narzędzia. `generated_utc` dokumentu musi mierzyć serializer w chwili faktycznego zapisu już przygotowanej treści. Agent Write-start na kilka minut przed zapisem nie jest generated_utc. Jeśli znasz tylko czas operacji/harnessu lub przybliżenie, nazwij go tak i użyj null+UNKNOWN dla nieznanego czasu; nie dopisuj „recorded in tool output”, którego output nie potwierdza. Mtime to osobny pomiar, nie zamiennik każdego pola czasu.

**MAX_ERROR_CORRECTION_ROUNDS=2 działa od pierwszego wykonania własnego narzędzia i obejmuje kod, wyniki, rekordy, raporty, QC oraz materializację.** Każde sprostowanie błędu już zapisanej własnej wersji liczy się także pod nową nazwą i w nowym dispatchu. Nie ma wyłączenia „production iteration”, „pre-QC”, „cosmetic” lub „first write of the corrected final pathname”. Zaplanowany pierwszy zapis nowego poprawnego dokumentu nie jest naprawą; poprawianie błędu starego draftu przez nowy final jest naprawą.

Runda to jawny zbiór korekt po konkretnym wykryciu, z zapisanym otwarciem/zamknięciem i PRE/POST hashami. Po zamknięciu nie dopinaj późniejszej poprawki do tej samej rundy. Nie zaliczaj ponownego odczytu, nowego pomiaru lub samego disclosure jako naprawy, jeśli nie zmieniają wadliwego artefaktu ani nie zastępują jego claimu poprawioną wersją.

Po wyczerpaniu limitu nie poprawiaj dalej. Zachowaj wadliwą wersję, ujawnij OPEN finding i PARTIAL w planowanym pierwszym raporcie/terminalu. Nie fabrykuj PRE, brakującego result object, hashów lub timestampów. Nie odtwarzaj wcześniejszych utraconych wyników jako oryginałów. Nie stosuj refreeze ani resetu licznika przez „freeze was premature”.

## 10. Artefakty i zamknięcie

Wymagane: PREFLIGHT.json, RUN_CONFIG.json, PREREGISTRATION.json, SOURCE_READS.json, pełne bufory/decode outputs/INSTRUCTION_ROSTER.json, EVIDENCE.json, controls z pełnymi wynikami, ATTEMPT_LOG.jsonl, QC.json (oraz fresh-QC jeśli rzeczywiście wykonane), BUDGET_USED.json, REPORT.md, HANDOFF.md, STAGE_ACCEPTANCE_GATES.csv, artifact_index.csv, MANIFEST_SHA256.csv. Format pomocniczy wybieraj oszczędnie; nie twórz ogólnego frameworka.

EVIDENCE zawiera ≤12 provenance rows, warianty, modele, typed status i jawny zakres porównania decoderów. BUDGET_USED ma rzeczywiste liczniki z list; raport/HANDOFF odwołują się do źródła, nie tworzą ręcznie niespójnych terminali. Final REPORT.md zapisz po QC; nie twórz planowanego draftu pod tą samą nazwą, który potem trzeba nadpisać.

Po science/QC: drugi hash EXE jeśli science rozpoczęto; re-hash wszystkich inputs i INPUT_PINS/kontraktu; ścisły parse wszystkich JSON/JSONL (odrzuć duplicate keys, NaN, Infinity). Pusty stderr/stdout zapisuj jako .txt lub .bin; nie ukrywaj błędu składni claims pod nazwą capture. Nowe niepoprawne dokumenty blokują pozytywną kwalifikację. Zachowaj rzeczywisty negatywny wynik.

artifact_index i manifest generuj z faktycznego census, nie z prognozy. Nie wpisuj self-hasha indeksu do indeksu; jawnie określ jego zakres. Manifest obejmuje KAŻDY fizyczny plik poza samym sobą: zero innych wykluczeń, próbek, braków, extra, duplicate. Zakres/kody/attempts/results muszą się mieścić w licznikach również po materializacji.

**MANIFEST_SHA256.csv jest ostatnim zapisem w OUTPUT_ROOT.** Po nim wyłącznie read-only full re-hash/bijekcja. SIZE/SHA manifestu i wynik weryfikacji zwróć w wiadomości terminalnej poza pakietem. Nie dopisuj logu/capture/QC do frozen root. Jeśli późniejsze sprawdzenie wykaże defekt, zgłoś go w wiadomości, bez zmiany pakietu.

## 11. Terminal, standing i HARD STOP

EVIDENCE_STATUS używa CONFIRMED / STRONGLY_SUPPORTED / PLAUSIBLE / UNVERIFIED / REJECTED, z osobnymi flagami scope/model. Nie myl tego z RUN_STATUS ani SCIENCE_RESULT.

RUN_STATUS dozwolone: COMPLETE_WITHIN_BOUND, PARTIAL, BLOCKED_PREFLIGHT, BLOCKED_TOOLING, NOT_QUALIFIED_TOOL_LIMIT. COMPLETE_WITHIN_BOUND jest stanem ukończenia procesu, nie kanonicznym gate PASS ani dowodem odzyskania XYZ. Przy materialnym OPEN finding, disagreement lub przekroczeniu limitu nie deklaruj pełnego ukończenia w granicach.

SCIENCE_RESULT dozwolone: WRAPPER_CURSOR_RELAY_CONFIRMED_CONDITIONAL_ON_DECLARED_MODELS, LOCAL_CURSOR_ORIGIN_OBSERVED_WITH_STATED_SCOPE, NOT_ESTABLISHED_WITHIN_BOUND, NOT_QUALIFIED_TOOL_LIMIT. Nie wymuszaj relay, tag=1 ani expected success. Jeśli bajty przeczą wskazówce, zachowaj ten wynik bez zmiany okna.

Rozdziel naukę szwu, dyspozycje findings, wykonanie gate, człowieka/QC, persistence i efekt canonical. Poprzedni PARTIAL nie zmienia się przez wynik tego runu. Nie ustalaj nadrzędnej roli w świecie ani lokalizacji wyłącznie z sukcesu małego mostu.

Nowy typed standing:

```ini
FIELD_SEMANTICS = UNVERIFIED_EXCEPT_SCOPED_WIDTH_AND_ADDRESS_FACTS
CURSOR_SOURCE_MEDIUM = UNKNOWN
CURSOR_CONSTRUCTION_OR_FILL_UPSTREAM = NOT_ESTABLISHED
ACTUAL_ADVANCE_HELPER_EFFECTS = NOT_ESTABLISHED
ACTUAL_VIRTUAL_CALLEE_TARGET = NOT_ESTABLISHED_UNLESS_DIRECTLY_EVIDENCED_IN_SCOPE
ACTUAL_VIRTUAL_CALLEE_EFFECTS = NOT_ESTABLISHED
ALLOCATION_RETURN_EQUALS_INITIALIZATION_RETURN = NOT_ESTABLISHED
STATIC_BUILDING_ROLE = NOT_ESTABLISHED
MODEL_218757_TO_THIS_PARSER_INSTANCE = NOT_ESTABLISHED
MODEL_218757_TO_CMO_JOIN = NOT_ESTABLISHED
WORLD_INSTANCE_IDENTITY = NOT_ESTABLISHED
HISTORICAL_PLACEMENT = NOT_ESTABLISHED
WORLD_XYZ_RECOVERED = NO
PREDECESSOR_PROCESS_TERMINAL = PARTIAL
RETROACTIVE_AUTHORIZATION = NO
CANONICAL_GATE_EFFECT = NONE
REPOSITORY_MODIFIED = NO
COMMIT_PUSH = NOT_PERFORMED
EXTERNAL_POSTAUDIT_OF_THIS_RUN = PENDING
NEXT_EXPERIMENT_AUTHORIZED = NO
NEXT_MILESTONE_AUTHORIZED = NO
HARD_STOP = YES
```

Historyczny standing źródłowego runu zachowaj jako źródłowy zapis z osobnym opisem supersessions; nie przepisuj dawnych PENDING ani wadliwych historycznych JSON. Powyższy nowy block sprawdź maszynowo względem kontraktu, zamiast ręcznie zgadywać liczbę kluczy.

Zwróć: RUN_ID, RUN_STATUS, SCIENCE_RESULT, C/O wejścia i transferu, exact transfer VA/form/target, B width/guard/gate, wszystkie przesłanki i warianty, relay vs producer, decoder coverage/differences, kontrole cases/outcomes/attempts, faktyczne limity, rundy korekt, QC_ORIGIN/findings, SOURCE_UNCHANGED w zmierzonym zakresie, manifest rows/physical/SIZE/SHA oraz ścieżkę REPORT.

FIRST_MISSING_EDGE nazwij wyłącznie: po relay — „kto dostarcza C do FUN_00852A30 i gdzie konstruuje/wypełnia jego bufor”; jeśli local origin pozostanie nieustalony — ostatnia faktycznie sprawdzona granica. To propozycja do odrębnej decyzji, nie automatyczne zlecenie.

Zakazane: callerzy wrappera, dalsze hops, body helpera0x0040DE60, ponowne otwarcie FUN_00852750 lub jego callees, vtable/RTTI/data xrefs, whole-text/callgraph census, inne regiony EXE, runtime/client/network, VFS/BNT/ARK/NIF, SDK research, renderer/viewer/world changes, repo-write, indeksy kanoniczne, skills/Obsidian, commit/push. Nie przygotowuj ani nie wykonuj następnego micro-runu. Po terminalu HARD STOP.
