# PE_935_PARAMETER_RECORD_INGRESS_R1_20261016 — REPORT (FINAL, materialization dispatch)

RUN_ID = PE_935_PARAMETER_RECORD_INGRESS_R1_20261016
RUN_CLASS = BOUNDED_STATIC_DATA_PROVENANCE_MICRORUN
ERA = PCG_9_3_5
DISPATCH = B_FINAL_MATERIALIZATION (post fresh-context QC; MANIFEST_SHA256.csv is written as the ABSOLUTELY LAST package file after this report)
EVIDENCE_COMMIT = 3fbe93eec04759395223e6677b5040273d29222a
BASE_SHA = NOT_APPLICABLE_PRIVATE_RUN_NO_GIT
generated_utc = 2026-10-16T12:47:23Z
time_provenance = PowerShell [DateTime]::UtcNow measured immediately before this document write (per the fresh review's P2-1 revalidation predicate: document time fields are measured at write time, never written from session memory)

## 1. LOCAL_INGRESS_RESULT

**PARTIAL**

This terminal is disclosed honestly per contract section 7 ("Po 2 rundach ujawnij PARTIAL, bez trzeciej") and the fresh-context review's recommendation (qc_fresh/QC_FRESH_REVIEW.json, qc_verdict QC_PARTIAL). PARTIAL is an allowed terminal of contract section 8. It is a PROCESS-terminal. It is NOT a retraction of any scientific claim. The two components are kept explicitly separate:

**(a) SCIENCE RESULT — the data-ingress seam, as SCOPED EVIDENCE (not retracted):**
The seam of FUN_00852750 is established **CONFIRMED_STATIC_CONDITIONAL_IN_EXAMINED_MODEL as scoped evidence** inside the examined window [0x00852750, 0x00852902) of the pinned Entropia.exe (SHA256 E7785430E81DFFE648CE8F5312414B17BC9FCE61389689A22F753765D5280F31, verified by two full streaming hash passes), decoded independently by GNU objdump 2.44 (PATH_A) and the pinned x86dec_pinned.py (PATH_B) with **133/133 instruction-head+length+raw-byte agreement and 32/32 call/branch-target agreement, 0 disagreements**. The separately dispatched fresh-context review (qc_fresh/QC_FRESH_REVIEW.json, controls QC-R2/QC-R3) **independently re-verified every load-bearing instruction, target and roster row from the saved buffer bytes** (own byte-level re-derivation, own independent PATH_A parse, full 133-row roster verification against the raw buffer) and **did NOT retract any scientific claim of this run**. Identity claims that depend on register preservation across opaque CALLs remain **CONDITIONAL_ON_ABI_MODEL**; ACTUAL_CALLEE_EFFECTS and preservation without that condition remain NOT_ESTABLISHED.

**(b) PROCESS-TERMINAL — why the RUN terminal is PARTIAL, not CONFIRMED_STATIC_CONDITIONAL_IN_EXAMINED_MODEL:**
1. The shared error-correction-round counter is exhausted: **rounds used 2/2, 0 remaining** (round 1 = t05 v1 wrapper KeyError; round 2 = wrong-output-root relocation; binding record: REPAIR_ROUND_2/REPAIR_ROUND_2.json + ATTEMPT_LOG entries 0019/0020). Contract section 7 requires disclosing PARTIAL after 2 rounds.
2. **P2-1 (open, material, unfixable — 0 repair rounds remain)**: agent-authored timestamps in the append-only ledger and in document metadata fields are demonstrably unfaithful to the physical write times, including three ledger entries carrying a FALSE "UTC recorded in tool output" precision claim (full instances and evidence in section 9.1). The science content is unaffected (independently re-verified from bytes by the fresh review), but the records-integrity defect is material and cannot be repaired within this run.

The scoped science result stands as evidence inside the PARTIAL package. Zero false PASS: the process findings P2-1/P3-1/P3-2/P3-3 are all disclosed in section 9.

## 2. Answer to the question (receiver / argument / K) — scoped evidence, all from bytes

At the virtual **CALL @0x008528B2** (`ff d0`, CALL EAX):

- **RECEIVER** = the pointee of EDI: vtable loaded `mov edx,[edi]` @0x008528AA (`8b 17`), receiver register ECX := EDI @0x008528B0 (`8b cf`, MOV ECX,EDI). Identified as **R = the return of the initialization CALL 0x0085287F @0x00852884 (`8b f8`, MOV EDI,EAX)** — **CONDITIONAL_ON_ABI_MODEL** (EDI preserved across one opaque CALL 0x0084feb0 @0x008528A5).
- **ARGUMENT** = the pushed ESI value @0x008528AF (`56`, PUSH ESI). Identified as **C = the input cursor** — the single stack argument of FUN_00852750, loaded @0x00852783 (`8b b4 24 b0 00 00 00`, MOV ESI,[ESP+0xB0]; post-prologue [ESP+0xB0]=[ESP_entry+4]; RET 0x4 @0x008528EB confirms exactly one stack argument) — **CONDITIONAL_ON_ABI_MODEL** (ESI preserved across 8 opaque CALLs of the loop path).
- **CODE TARGET** = **V = [receiver_vtable+4]** loaded into EAX @0x008528AC (`8b 42 04`, MOV EAX,[EDX+4]). V is an indirect CODE ADDRESS — **not** an object pointer, **not** a model ID. ACTUAL_VIRTUAL_CALLEE_TARGET = NOT_ESTABLISHED_UNLESS_DIRECTLY_EVIDENCED_IN_SCOPE.
- **The DWORD passed earlier to the initialization** (CALL @0x0085287F, target 0x00852dc0) is **K**: a 32-bit read from the input cursor's data buffer at its current offset — `mov ebp,[ecx+eax*1]` @0x0085282B (`8b 2c 01`) where ECX=[C+0xC] (offset) and EAX=[C] (data) — under valid/size guards ([C+0x11]≠0; [C+0xC]+4 ≤ [C+0x8]) with an explicit zeroing branch (XOR EBP,EBP @0x00852839, `33 ed`) when guards fail. It is passed as the FIRST stack argument (`55`, PUSH EBP @0x00852874, pushed last of the two); the SECOND stack argument is the return of CALL 0x0084fe50 (`50`, PUSH EAX @0x00852873, guard-object constructor, receiver [ESP+0x24]); the receiver of the initialization is ECX = EDI = **A = the allocation return** (CALL 0x0095d3c4 with arg 0x90 @0x00852843-48, `e8 77 ab 10 00` + `68 90 00 00 00`; MOV EDI,EAX @0x0085284D). K reaching that PUSH with the read value is **CONDITIONAL_ON_ABI_MODEL** (EBP preserved across 3 opaque CALLs: 0x0040de60, 0x0095d3c4, 0x0084fe50).
- **A=R aliasing**: NOT_ESTABLISHED. The window saves A at [ESP+0x20] @0x00852852 (`89 7c 24 20`) and never re-reads it (fresh-review-verified from its own roster scan); the virtual-call setup consumes the R path (MOV EDI,EAX @0x00852884). Neither A=R nor A≠R is claimed.

Cursor struct fields read in-window (widths established from bytes): data@+0 (u32), size@+8 (u32), offset@+0xC (u32), valid flag@+0x11 (u8). The u16 read @0x008527A2 (`66 8b 04 10`) stored to [O+0xAC] @0x008527AA, the loop count @0x008527EC and K are **NOT** automatically class-id/instance-id/template-id — semantics UNKNOWN.

Full provenance with per-instruction raw bytes agreed by BOTH decoders: EVIDENCE.json provenance_rows 1-16 (roster reference: decode/INSTRUCTION_ROSTER.json, 133 rows).

## 3. Symbols established (each separately typed)

| Symbol | Definition | Established | Conditional/UNKNOWN |
|---|---|---|---|
| C | input cursor candidate = the single stack argument (ESI @0x00852783) | instruction bytes; cursor field offsets+widths | ESI=C at the PUSH: CONDITIONAL_ON_ABI_MODEL; source of C: UNKNOWN |
| O | entry ECX receiver (EDI @0x0085277D; stack anchor [ESP+0x1c] @0x0085277F) | in-window stack anchor, no ABI dependence; fields [O+0xAC] (u16) and [O+0x2C] (sub-object receiver) | class identity UNKNOWN |
| K | DWORD → EBP @0x0085282B | width 32-bit, guards, zeroing branch, origin = cursor data buffer at current offset | value at PUSH: CONDITIONAL_ON_ABI_MODEL; semantics UNKNOWN |
| A | allocation return (0x90 B) @0x0085284D; receiver of init | bytes, null test, [ESP+0x20] save (never re-read) | A=R: NOT_ESTABLISHED |
| R | initialization return → EDI @0x00852884 | bytes; vtable loaded from [EDI] at the call | EDI=R: CONDITIONAL_ON_ABI_MODEL; callee effects NOT_ESTABLISHED |
| V | [vtable+4] in EAX @0x008528AC | indirect code address form (CALL EAX) | actual callee target/effects: NOT_ESTABLISHED |

## 4. ABI assumptions (explicit)

Conditional model: MSVC x86 with EBX/EBP/ESI/EDI callee-saved, ECX= thiscall receiver, args pushed right-to-left, callee cleans fixed args (RET imm16). In-window support: FUN_00852750 itself saves/restores EBX/EBP/ESI/EDI and returns RET 0x4 — consistent with the convention hypothesis for this compilation unit, but NOT proof of any specific callee's actual behaviour. A separate no-assumption model is recorded: under it, ESI/EDI/EBP/EBX after any opaque CALL are NOT_ESTABLISHED. No callee body was opened to recover cleanups. Caller-side cleanup (ADD ESP,4) is byte-visible after the alloc/delete calls only; callees' own stack discipline is NOT_ESTABLISHED. Counted opaque CALLs between load and use: ESI (C at the virtual call PUSH): 8; EBP (K at the init PUSH): 3; EDI (R at the vtable load): 1 (full lists in EVIDENCE.json abi_assumptions).

## 5. Decoder coverage

- PATH_A (GNU objdump 2.44, /usr/bin/objdump SHA256 96AFB8521834982D0E711B5D6E9785252BF82129FB0106B93A6BD54D83FAE11F): 1 full sweep (1/2), exit 0; 133 instruction heads; 3 wide-instruction continuation lines merged (not heads).
- PATH_B (x86dec_pinned.py, 27188 B / SHA256 C8E8470EFD762F66FF20369B2F656694C635131261F4D611DCA9C504E2B90B95, imported unmodified, no main, no .pyc): sequential sweep from offset 0, **133 decode applications (133/384), no barrier**, reached the window end exactly; **B was never fed A's heads** (independence verified by the fresh review, QC-R3: t04 code read in full).
- Comparison (decode/ab_comparison.json): **133/133 heads+lengths+raw; 32/32 targets (11 CALL rel32 + Jcc rel8/rel32 + JMP rel8 + 1 indirect CALL EAX); 0 disagreements**. Known PATH_B limitations (0x3C/0x3D, 0x9A/0xEA) were NOT exercised by this window (limitation reality and non-exercise both independently re-confirmed by the fresh review).
- The fresh-context review independently re-parsed PATH_A from the buffer bytes and re-verified all 133 roster rows against raw buffer bytes with 0 errors, reconfirming the A/B agreement WITHOUT using t05 (qc_fresh/QC_FRESH_REVIEW.json QC-R3).

## 6. Controls (4/4 required refusals)

- C1 callsite on an interior byte (0x008528B3, the D0 of FF D0): **REFUSED** (CONTROL_PASS)
- C2 code target V described as receiver/object ID: **REFUSED** (CONTROL_PASS)
- C3 argument/receiver registers swapped: **REFUSED** (CONTROL_PASS)
- C4 UNKNOWN source medium/world role promoted to NETWORK/STATIC_BUILDING/XYZ: **REFUSED** (CONTROL_PASS)

Semantics: CONTROL_PASS = the required refusal for that specific counter-trial on a COPY of the claims record; not a falsification proof; not a universal validator. Full mutant structures, actual loader paths, outcomes, reasons: controls/ (fresh-review verification: QC-R4).

## 7. Budgets (actual/limit, from physical lists; binding state)

| Budget | Actual | Limit |
|---|---|---|
| window reads / bytes | 2/2 | 868/868 B |
| header reads / bytes | 1/1 | 4096/4096 B |
| full EXE hash passes | 2/2 | 2 |
| PATH_A full sweeps | 1/2 | 2 |
| PATH_B decode applications | 133/384 | 384 |
| unique instruction starts | 133/192 | 192 |
| accounted callsite units | 12/16 (11 direct E8 + 1 indirect FF D0) | 16 |
| symbolic states | 16/16 | 16 |
| new function bodies / callee bodies | 1/0 | 1/0 |
| additional saved inputs | 0/0 | 0 |
| synthetic decode applications | 0/0 | 0 |
| wrapper hops | 0/0 | 0 |
| **error correction rounds (BINDING)** | **2/2** | 2 |
| own files / bytes | final dynamic census: MANIFEST_SHA256.csv (self-excluded bijection) | 256 / 16 MiB |

Total original EXE bytes read: 16,036,708 (2×8,015,872 hashing + 4096 header + 2×434 window) = exactly the contract maximum at full budgets (within_budget=true; re-verified arithmetically by the fresh review).

**error_correction_rounds = 2/2 is the BINDING final state** (supersession P3-1, section 9.2): round 1 = t05 v1 KeyError target_va (v1 preserved, v2 new filename; ATTEMPT_LOG 0010/0011); round 2 = wrong-output-root relocation (byte-preserving, 49/49 identical; REPAIR_ROUND_2/ + ATTEMPT_LOG 0019/0020). Pre-relocation fields that state 1/2 (BUDGET_USED.json budgets.error_correction_rounds.actual=1; REPORT_v1_draft.md section 7 "1/2"; QC.json QC-13; ATTEMPT_LOG entry 0018) are the HISTORICAL record written BEFORE round 2 existed — preserved byte-untouched per the append-only rule; every reader of those files must apply this supersession.

## 8. QC chain

1. **QC.json** (executor self-QC): qc_origin = **SELF_REVIEW_WITH_LIMITATIONS**; 13 checks: 12 PASS + 1 PASS_WITH_DISCLOSURES (QC-13 process honesty: repair round 1 consumed at that time; UTF-16LE console captures vs tool-written UTF-8 JSON; no .pyc; no tools in external Temp; counters from lists). fresh_context_review_status = PENDING (historical, byte-untouched). Verdict PASS_WITH_DISCLOSURES. Limitations honestly stated (two algorithms of one author are not two audits).
2. **FRESH_CONTEXT_REVIEW** (separately dispatched, records-only): qc_fresh/**QC_FRESH_REVIEW.json** — reviewer pe-master-auditor (fresh context), review_run_id PE_935_PARAMETER_RECORD_INGRESS_FRESH_QC_R1_20261016, verdict **QC_PARTIAL**. This review CLOSES the QC.json fresh_context_review_status PENDING (the package's QC.json itself stays byte-untouched; append-only discipline). Scope: PROMPT_ROOT input copies (read-only) + saved buffers/documents of this package; **ZERO new reads of the original EXE** (executor budgets 2/2 hashes + 2/2 windows + 1/1 header were already exhausted); ZERO writes outside qc_fresh/. Controls QC-R1..QC-R7: pins re-hashed; every load-bearing instruction re-derived from buffer bytes; independent PATH_A re-parse; full 133-row roster verification; substantive control-mutant verification; budgets recomputed from lists; ledger hash-chain reconstruction. Findings: **P2-1** (material, open, unfixable), **P3-1** (superseded census drift — binding 2/2), **P3-2** (RESOLVED, not a defect), **P3-3** (cosmetic, corrected in THIS final report). Science content NOT retracted.
3. **QC_ORIGIN (final)** = SELF_REVIEW_WITH_LIMITATIONS (executor) + FRESH_CONTEXT_REVIEW (qc_fresh/, QC_PARTIAL). **EXTERNAL_POSTAUDIT_OF_THIS_RUN = PENDING.**

## 9. Process findings (fresh-context review, qc_fresh/QC_FRESH_REVIEW.json)

### 9.1 P2-1 — OPEN, material records-integrity defect, unfixable (0 repair rounds remain)

Agent-authored timestamps in the append-only ledger and document metadata fields are demonstrably unfaithful to the physical write times; three ledger entries additionally carry a FALSE "UTC recorded in tool output" precision claim. Instances (all from QC_FRESH_REVIEW.json findings/P2-1, independently measured by the reviewer):

- ATTEMPT_LOG entry 0006: claims 10:25:00–10:25:30Z "UTC recorded in tool output", but the cited tool output (records/pe32_mapping.json) says 10:26:04.407320Z.
- ATTEMPT_LOG entry 0014: claims 10:59:00–10:59:30Z "recorded in tool output", but records/SOURCE_UNCHANGED.json says 10:53:32.917177Z.
- ATTEMPT_LOG entry 0017: claims 11:12:00–11:12:30Z, but records/JSON_VALIDATION.json says 11:02:25.648333Z (and BUDGET_USED.json physically existed by 11:02:20, making 11:12 impossible).
- Ledger vs mtime: entry 0008 (claimed 10:30:00; PATH_A capture mtime 10:28:41); entry 0015 (claimed 11:01–11:03; mtimes 10:55:06/10:59:05); entry 0016 (claimed 11:08–11:10; mtimes 11:02:08/11:02:20); entry 0010 (marked approximate; claimed 10:32:00; capture mtime 10:35:13).
- Document metadata vs mtime: QC.json checked_at_utc 10:57:00Z vs mtime 10:52:53; SOURCE_READS.json generated_utc 11:01:00Z vs mtime 10:55:06; records/JSON_VALIDATION_ADDENDUM.json generated_utc 11:08:00Z vs mtime 11:02:08; BUDGET_USED.json generated_utc 11:10:00Z vs mtime 11:02:20.
- Consistent baseline: ALL tool-written timestamps match their file mtimes to the second (t01 10:23:27 … t08 run-2 11:02:25) — the filesystem clock was sound; the drift is confined to agent-authored time fields (written from session-memory estimates, including false precision-provenance claims). Post-census integrity: 48/49 POST_CENSUS files byte-identical at review time, so no post-run edit explains the mtimes.

Disposition: **OPEN** — no repair rounds remain; the affected historical files stay byte-untouched (append-only). The science content is NOT affected (every load-bearing claim independently re-verified from raw bytes by the fresh review). Revalidation predicate for future runs: every ledger time field must be copied from the tool output it cites (or explicitly marked approximate); generated_utc/checked_at must be measured at write time. THIS materialization dispatch applies that predicate to every new field it writes (see time_provenance above and the materialization ledger entries).

### 9.2 P3-1 — pre-relocation repair-round census drift (SUPERSEDED; binding state disclosed here, historical fields untouched)

BUDGET_USED.json (error_correction_rounds actual=1), REPORT_v1_draft.md section 7 ("1/2"), QC.json QC-13 and ATTEMPT_LOG entry 0018 all state 1/2 — all written BEFORE repair round 2 (wrong-root relocation). The BINDING state is **2/2, 0 remaining** (REPAIR_ROUND_2/REPAIR_ROUND_2.json "rounds used 2/2, remaining 0"; ATTEMPT_LOG 0019/0020). Historical fields are preserved byte-untouched; this final report and the final package metadata carry 2/2 (section 7). Not a new defect; disclosed supersession.

### 9.3 P3-2 — identical time_start==time_end in t05v2/t08-run2 — RESOLVED_NOT_DEFECT

Physically explainable: the environment's clock advances in ~15.65 ms ticks at that moment (qc_fresh/qf07_clock_probe_result.json); the tools' work spans (≈2–6 ms) fit inside one tick. Other tools show real deltas (0.99–12.7 ms); both runs' mtimes match their claimed times to the second, so the executions are genuine. Not a fabrication indicator.

### 9.4 P3-3 — cosmetic: sentence-final period in the draft standing block — noted, corrected here

REPORT_v1_draft.md line 90 ended "HARD_STOP = YES."; the contract value is "YES". All 19 keys matched after stripping the period (own comparison by the fresh review). THIS final report renders the standing block (section 11) without sentence-final punctuation inside any value field.

## 10. SOURCE_UNCHANGED

YES — full EXE hash pass 2 = pass 1 = pin E7785430E81DFFE648CE8F5312414B17BC9FCE61389689A22F753765D5280F31; all 11 input copies + INPUT_PINS.json + the contract re-hashed after science, 13/13 match (records/SOURCE_UNCHANGED.json, attempt 0014). The fresh review re-hashed the 11 copies and INPUT_PINS against the pins on its own (11/11 + pins match) with ZERO new reads of the EXE. No whole-file copy of the EXE was ever written; the only EXE bytes in the package are the permitted 4096-B header buffer and the two 434-B window buffers (byte-identical, SHA256 6A7D19DB23BC960761715D27084E185E876577736787BFA7AAADCDAEF32DAD0F).

## 11. Standing (typed final-status block, contract section 8 verbatim — 19 keys, no sentence-final punctuation)

```ini
FIELD_SEMANTICS = UNVERIFIED_EXCEPT_SCOPED_WIDTH_AND_ADDRESS_FACTS
CURSOR_SOURCE_MEDIUM = UNKNOWN
ACTUAL_VIRTUAL_CALLEE_TARGET = NOT_ESTABLISHED_UNLESS_DIRECTLY_EVIDENCED_IN_SCOPE
ACTUAL_VIRTUAL_CALLEE_EFFECTS = NOT_ESTABLISHED
ALLOCATION_RETURN_EQUALS_INITIALIZATION_RETURN = NOT_ESTABLISHED
STATIC_BUILDING_ROLE = NOT_ESTABLISHED
MODEL_218757_TO_THIS_PARSER_INSTANCE = NOT_ESTABLISHED
MODEL_218757_TO_CMO_JOIN = NOT_ESTABLISHED
WORLD_INSTANCE_IDENTITY = NOT_ESTABLISHED
HISTORICAL_PLACEMENT = NOT_ESTABLISHED
WORLD_XYZ_RECOVERED = NO
RETROACTIVE_AUTHORIZATION = NO
CANONICAL_GATE_EFFECT = NONE
REPOSITORY_MODIFIED = NO
COMMIT_PUSH = NOT_PERFORMED
EXTERNAL_POSTAUDIT_OF_THIS_RUN = PENDING
NEXT_EXPERIMENT_AUTHORIZED = NO
NEXT_MILESTONE_AUTHORIZED = NO
HARD_STOP = YES
```

## 12. Historical standing 20/20 (source-run record, preserved, with supersessions described separately)

The historical standing 20/20 of the source run (PE_935_WORLD_MODEL_BRANCH39_SINGLE_CALL_PROVENANCE_R1_20261014) is preserved VERBATIM in EVIDENCE.json historical_standing_source_record (source: inputs/HISTORICAL_STANDING_SOURCE.json). Its PENDING items are NOT rewritten and the malformed qc_fresh/QC_FRESH_CONTEXT.json of the BRANCH39 addendum is NOT corrected by this run. Later process supersessions are described separately there (BR39-PROC-1/2 P2 accepted in examined saved scope; the addendum's AD39-JSON/AD39-INPUT/AD39-BUDGET (P2) and AD39-RETENTION (P3) process findings) — they supersede that addendum's process claims only; the historical BRANCH39 science result (ANCHOR_NOT_ESTABLISHED) stands, and its science-scope statements (no model join, no placement, no XYZ) remain in force for this corpus. No absence of a producer in this window is a NO_PRODUCER_ANYWHERE claim.

## 13. Explicit UNKNOWNs / missing edges / CURSOR_SOURCE_MEDIUM

- **FIRST_MISSING_EDGE (named, NOT executed)**: (1) the source of C — who constructs/fills the input cursor that FUN_00852750 receives; (2) the fields read inside the virtual callee; (3) the role of the static instance that owns this parser. The trace ends at entry to the virtual parser.
- **CURSOR_SOURCE_MEDIUM = UNKNOWN** (memory as the direct source does not establish a historical medium — no file/network/cache/queue claim).
- The window is a frozen read limit, not an independently proven complete CFG; the failure epilogue and the return JMP were included (the run did not end at the first RET).
- Allocation-failure variant: a structural NULL dereference at 0x008528AA (static observation only; runtime not examined).
- All 12 callees remain opaque (0 callee bodies opened); no xref/callgraph census; no B9/BRANCH39 analysis; no other EXE regions.

## 14. Repair rounds accounting (both consumed, disclosed)

- **REPAIR_ROUND_1** (t05 wrapper defect): first execution of tools/t05_compare_ab_and_roster.py v1 crashed with KeyError target_va (the pinned library records no imm for unprefixed rel32 E8/E9); fixed in t05_compare_ab_and_roster_v2.py (new filename; v1 preserved unmodified). Disclosed in ATTEMPT_LOG 0010 (FAILED) / 0011 (v2 OK). Fresh-review verification of the failure mechanism: QC-R6 (v1 line 113 read in full; pinned library imm_width=0 for unprefixed E8/E9).
- **REPAIR_ROUND_2** (wrong-output-root relocation): the entire Dispatch A package (49 files / 424,352 B as found) had been written under the read-only PROMPT_ROOT evidence area; defect established by PE-MASTER, re-confirmed physically, repaired by a byte-preserving directory relocation to the contract OUTPUT_ROOT with PRE/POST census bracketing (49/49 identical size+SHA256), PROMPT_ROOT re-verified pristine (11/11 inputs + INPUT_PINS + contract match pins; opencode_output absent), PREFLIGHT_v2 supersedes the wrong output_root (v1 untouched), PATH_SUPERSESSION recorded as BINDING for all future tooling — including the manifest generator of this dispatch, which was authored with the corrected root from the start. Full record: REPAIR_ROUND_2/ (4 files) + ATTEMPT_LOG 0019/0020. 14 historical files retain superseded-path strings as historical evidence (byte-untouched).

## 15. Manifest note

**MANIFEST_SHA256.csv is written as the ABSOLUTELY LAST package file** (contract section 8), by tools/t09_manifest.py — a NEW tool authored in this dispatch with the CORRECT OUTPUT_ROOT hardcoded from the start (PATH_SUPERSESSION binding; zero wrong-root references). The manifest is a dynamic census of ALL physical files of the package except itself (self-excluded; zero exclusions, zero sampling; relative_path,size_bytes,sha256 per row; full bijection: 0 missing / 0 extra / 0 duplicate; the tool predicts NO file count — the census is discovered at run time). Before any manifest write, the tool performs the final strict JSON/JSONL parse validation of every package .json/.jsonl (fail-stop on any NEW parse failure; the single pre-classified 0-byte artifact attempts/ab_compare_stdout.json is disclosed, not masked). The manifest's SIZE_BYTES and SHA256 and the read-only re-verification result are reported in the TERMINAL MESSAGE ONLY and are NOT written into the package.

## 16. Key paths

- Final: REPORT.md (this file); draft preserved: REPORT_v1_draft.md (byte-identical rename of the Dispatch A draft; SHA256 AE888BB403173BC3680A0212113753376099A4E070826F289EC8CBAC027A3105)
- PREFLIGHT.json, PREFLIGHT_v2.json (binding output_root), PREREGISTRATION.json, SOURCE_READS.json, EVIDENCE.json, QC.json, BUDGET_USED.json, ATTEMPT_LOG.jsonl (append-only; materialization entries appended)
- buffers/: pe_header_first4096.bin, window_science_read1.bin, window_science_read2.bin
- decode/: INSTRUCTION_ROSTER.json (133 rows), ab_comparison.json, path_a_sweep_read1.txt (+utf8 copy), path_b_sweep_read1.json
- records/: pe32_mapping.json, SOURCE_UNCHANGED.json, JSON_VALIDATION.json, JSON_VALIDATION_ADDENDUM.json
- controls/: C1-C4 mutants + results + CONTROL_SUMMARY.json
- REPAIR_ROUND_2/: REPAIR_ROUND_2.json, PRE_CENSUS.json, POST_CENSUS.json, PROMPT_ROOT_REVERIFY.json
- qc_fresh/: QC_FRESH_REVIEW.json, QC_FRESH_REVIEW_SUMMARY.md, qf01-qf07 results + scripts
- tools/: t01-t08 (versioned; t05 v1 preserved + v2) + t09_manifest.py (this dispatch)
- attempts/: run captures (incl. t09_verify_stdout.json from this dispatch's verify-only pass)
- MANIFEST_SHA256.csv: written after this report as the LAST file (see section 15)

HARD_STOP = YES — no next experiment or milestone is authorized by this report
