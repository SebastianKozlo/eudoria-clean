# Ocena kierunku po Fixed Candidate Provenance

Werdykt: **ACCEPTED_WITH_CORRECTIONS_AND_NARROWING**. Właściwy jest powrót do istniejących dowodów Rosetty i wybranie jednej brakującej krawędzi. Nie należy powtarzać podstawowego censusu 27 VFS ani skanu 13 kandydatów. W propozycji są jednak dwa błędy kotwic oraz zbyt szerokie utożsamienie mechanizmu writera z pochodzeniem konkretnej późniejszej wartości.

To jest przegląd zapisanych dowodów, nie nowy eksperyment na grze. Odczytano raporty, istniejące okna bajtowe i obiekty Git przypięte do `3fbe93eec04759395223e6677b5040273d29222a`. Wyeksportowano 32 pliki, zapisując ich Git blob, rozmiar i SHA256 w `SOURCE_IDENTITIES.json`. Tożsamości kopii sprawdzono skryptem. Nie jest to pełna ponowna kwalifikacja wszystkich historycznych runów.

**Oryginalne VFS, BNT i Entropia.exe nie zostały otwarte. Repozytorium nie było modyfikowane.** Próba sprawdzenia live ref przez lokalny Git zakończyła się błędem brakującego helpera `remote-https`. Nie deklaruję aktualnego live master. Wskazany SHA jest niezmiennym snapshotem dowodowym, a nie świeżym pomiarem zdalnej gałęzi.

## 1. Co w proponowanej korekcie jest trafne

- Podstawowy census jest już dostępny: 27 plików, raportowane 14 825 rekordów. Nowy census miałby sens dopiero dla konkretnej, niepokrytej właściwości danych. Same rozkłady rozmiarów nie ustanawiają wspólnego schematu ani roli świata.
- `477` i `2437` nie występują jako outer RID w sprawdzonej zapisanej mapie templates; `4057` występuje raz. Prosty wariant hipotezy „trzy klucze tej samej mapy templates” nie uzyskał wsparcia. To nie obala każdego możliwego znaczenia sekwencji w hierarchy.
- Fixed stride zastosowany do całego kontenera może skleić różne ramki, nagłówki i padding. Nie wyklucza to rekordów o stałym kroku wewnątrz określonego payloadu.
- Dla hierarchy nie mamy schematu wewnętrznego pozwalającego orzec, że cały plik nie zawiera placementu. Uczciwy wynik brzmi: żaden z badanych 13 layoutów nie został zakwalifikowany jako historyczny rekord instancji budynku.
- F1–F3 pozostają ograniczeniami procesu. Nie wolno fabrykować PRE, czasu korekty ani drugiego wykonania kontroli C13. Korekta raportującego assemblera nie oznacza zmiany zamrożonych czytników.

Podstawą tych punktów są wcześniejszy `PE_PLACEMENT_NEXT_DIRECTION_REVIEW_20261011` i zewnętrzny `PE_PLACEMENT_FIXED_CANDIDATE_POSTAUDIT_20261011`. Nie ponawiałem dekodowania całego ich korpusu w tym przeglądzie.

## 2. Błąd zakresu: 61, nie 62

Zapisane okno `FUN_007080C0`, porównane z dziewięcioma aktualnymi pinami, zawiera:

```text
0x007080D6: BE 20 4E 00 00        ESI := 20000
0x007080E8: 83 C6 01              ESI += 1
0x007080EB: 81 FE 4C 4E 00 00     CMP ESI, 20044
0x007080F1: 72 ED                 JB

0x007080F3: BE C1 5D 00 00        ESI := 24001
0x00708100: 83 C6 01              ESI += 1
0x00708103: 81 FE D2 5D 00 00     CMP ESI, 24018
0x00708109: 72 ED                 JB
```

Badane pętle obejmują **[20000, 20044) i [24001, 24018)**, czyli **20000–20043 oraz 24001–24017: 44 + 17 = 61 wartości**. `20044` jest granicą wyłączną. Nie jest to dowód kompletnego rejestru wszystkich klas klienta.

Porównanie z istniejącym `PARAMETERS_REVERSE_CANDIDATES.json` daje:

| Jednostka | Wynik |
|---|---:|
| Nazwy liczbowe VFS | 19 |
| Nazwy nieliczbowe VFS | 8 |
| Nazwy liczbowe mieszczące się w badanych pętlach | 19/19 |
| Nazwy liczbowe poza badanymi pętlami | 0 |
| Wartości z pętli bez odpowiadającej nazwy liczbowej w historycznym censusie | 42 |

Pełne wyniki są w `NAME_AND_ANCHOR_CHECKS.json` i `NUMERIC_VFS_CLASS_COMPARISON.csv`. `20006.vfs` nie występuje w tym censusie. Nie oznacza to braku klasy 20006, braku wartości tej klasy, wykluczenia pliku/cache ani dowodu źródła sieciowego.

Zgodność nazw wspiera konwencję nazewniczą. Zdanie „przypadkowa zgodność jest mało prawdopodobna” nie ma tu policzonej podstawy: brak modelu zerowego, niezależnego doboru przedziałów i populacji porównawczej. Nie jest potrzebne, ponieważ dla 20002 istnieje mocniejszy dowód z kodu.

## 3. Błąd rodzaju adresu napisów

Aktualne zapisane piny dają:

| Instrukcja | Bajty | VA wskazanego napisu |
|---|---|---|
| PUSH @0x004B09F3 | `68 58 A2 A7 00` | `0x00A7A258`: `Parameters\` |
| PUSH @0x004B09CD | `68 3C A8 A7 00` | `0x00A7A83C`: `Cache\` |

**`0x0067A258` i `0x0067A83C` nie są VA tych napisów.** Nie ustalam tu, czy w pierwotnym dokumencie oznaczały RVA lub file offset; do tego potrzebne byłoby jawne mapowanie. Kolejny kontrakt musi przechowywać `ADDRESS_KIND` osobno i nie używać tych liczb zamiennie.

## 4. Class-id → VFS → reader już istnieje dla 20002

Załączony audyt słusznie wskazuje `VFS_TO_PARSER_TRACE.md`. W zapisanym wcześniejszym RE dla **ArkParameterArmor / 20002** udokumentowano:

```text
class id z [classObj+8]
→ FUN_0070C3D0: konwersja liczby i dołączenie .vfs
→ FUN_0070C680: obiekt 0xA4, ctor FUN_00972380
→ store [factory+0x84] @0x0070C71E
→ CALL FUN_00972DF0 @0x0070C742: otwarcie
→ reader/index/rekord
→ FUN_00971AD0 / FUN_00971650
→ FUN_0070DC20 / FUN_00726900: zastosowanie właściwości
```

Istotna kolejność: **store poprzedza wywołanie open**. Nie przedstawiaj otwarcia pliku jako operacji, która dopiero potem przypisuje wskaźnik do `+0x84`.

To potwierdzony wcześniejszy mechanizm dla zbadanej klasy i ścieżki. Nie dowodzi, że konkretna wartość klasy 20006 została dostarczona z `20006.vfs`. Nie dowodzi też instancji świata. Dla 20002 zerowe pola CRC oznaczały pominięcie kontroli CRC, a nie niezależnie potwierdzone CRC wszystkich rekordów.

Aktualna korekta factory84 zachowuje assignment jako `CONFIRMED_STATIC_CONDITIONAL`; obiekt ma **0xA4 = 164 B**, ctor `FUN_00972380`. Nie przywracamy starszej pewności co do vtable, polimorfizmu ani nazwy „stream” dla tego konkretnego obiektu tylko na podstawie historycznego opisu. Tożsamość statycznego membera jest czymś innym niż tożsamość jego wartości przy dowolnym późniejszym zdarzeniu.

## 5. Writer table[10] też jest już znany

Najważniejsze uzupełnienie do załącznika pochodzi z istniejącego pakietu `FUN_0070DC20_TABLE10_WRITER` oraz jego korekty W3:

```text
record cursor
→ tag u16
→ schema descriptor: tag 6 → id 10
→ [component+0x40] + 10*4
→ traits dispatch FUN_0075F660
→ FUN_009777F0
→ READ 8B 04 10 @0x00977807
→ WRITE 89 02 @0x00977810
```

Mechanizm writera jest potwierdzony statycznie warunkowo. Getter strukturalnie adresuje tę samą komórkę magazynu przez zbadany układ factory/receiver/cache. **Nie jest potwierdzone zachowanie konkretnej zapisanej wartości aż do konkretnego późniejszego odczytu.**

Obowiązujące rozróżnienie:

| Twierdzenie | Status po korektach |
|---|---|
| Istnieje mechanizm zapisu wartości rekordu do table[10] | CONFIRMED_STATIC_CONDITIONAL |
| Getter może adresować tę samą komórkę magazynu | CONFIRMED_STATIC_CONDITIONAL |
| Ten konkretny write jest producentem tego konkretnego późniejszego getter result | UNVERIFIED |
| Brak clobber/re-apply między write i read | NOT_ESTABLISHED |
| Najgłębsze pochodzenie wartości | UNKNOWN |
| Wynik getter normal branch trafia jako klucz lookupu | PRESERVED_CONFIRMED, z warunkami ścieżki |

Istnieją już udokumentowane, ale niezamknięte powierzchnie mogące zmieniać stan: mode-1 reader przez vtable, delegate notify/release, re-apply w drugim callerze. To nie dowodzi, że wartość zmieniają; uniemożliwia bezwarunkowy wniosek o jej zachowaniu.

Z tego powodu historyczne `FIRST_MISSING_EDGE=INSERTED_VALUE_TO_PLACEMENT_CONSUMER` nie powinno być kopiowane jako jeden uniwersalny opis. Dla toru mechanizmu writera granica jest inna niż dla konkretnego zdarzenia, fizycznego źródła danych i modelu 218757. Każdy tor potrzebuje własnej pierwszej brakującej krawędzi.

## 6. Normal branch i alternative branch trzeba rozdzielić

Normalna badana ścieżka `FUN_004C5480` ma selector 20006, tag6, id10 i odczyt current u32. Nie wszystkie zwroty tej funkcji mają takie pochodzenie.

Korekta GP2 zachowuje alternatywną ścieżkę z `FUN_00843340`: omija segment tag6, ale wraca do wspólnego callera `FUN_004C5580`. **Niezerowy wynik alternatywy też może zostać kluczem `FUN_0072F880`.** Semantyka tego wyniku pozostaje UNKNOWN. Sam wspólny lookup nie identyfikuje producenta.

Nie wolno zatem połączyć dowodu normalnego zapisu table10 z dowolnym wywołaniem wspólnego lookupu ani utożsamić każdego klucza z 4057 lub 16083.

## 7. Rekord 4057: układ słów to jeszcze nie znaczenie

Z wcześniejszego zapisanego odczytu:

```text
[0] 4057
[4] 218757
[8] 218758
+0x0C 0
+0x10 0x41AA0F28 = f32 21.257400512695312
+0x14 0
+0x18 0
```

Istniejący parser definicji ma też fizycznie przypięty mechanizm odczytu pola D jako f32 i zapisu do pola obiektu template+0x10 (`FLD @0x00730D69`, `FSTP @0x00730D70`). To użyteczna, istniejąca informacja o schemacie; nie odkrycie gameplayowej semantyki D. Nie nazywamy D promieniem, wysokością, scale ani XYZ. Nie utożsamiamy payload+0x10 z transformem instancji.

Podobnie potwierdzone `4057 → 218757` jest relacją definicja/zasób. Do historycznej lokalizacji potrzeba nadal instancji, jej powiązania z zasobem, transformu i źródła tego transformu. Sids-4057 i template-4057 są różnymi przestrzeniami identyfikatorów. Zbadany immediate @0x0059AB12 prowadził do UI/string-table, nie do modelu 218757; nie jest właściwą kotwicą placementu.

## 8. Nie zamieniaj CMO ani Gamebryo w dowód statycznego budynku

W późniejszych korektach CMO zachowano warunkową tożsamość wartości wskaźnika między callami, ale `POINTEE_CONTENTS_PROVENANCE=UNRESOLVED_UPSTREAM`, `FIELD_SEMANTICS=UNVERIFIED` i `WORLD_INSTANCE_IDENTITY=NOT_ESTABLISHED`. To precyzyjniejsze niż zbiorczy skrót „komunikat → vec3 → instancja świata”. Nawet jeśli inne wcześniejsze dowody opisują transport danych, trzeba zachować ich receiver i zakres.

Zapis `[arg1+8] → MovableObject+0x44` nie ustanawia globalnego X ani budynku. Nie przywracamy wycofanej przez J3 kwalifikacji transform trace i nie przenosimy identity ACLD SceneFeeder na CMO.

Późniejsze supersessions FC-C1–FC-C3 dodatkowo wycofują pewność zachowania escaped-local value na growth path, rozłączność aliasów wywnioskowaną z różnych łańcuchów oraz kategoryczne wykluczenie utility z całego pipeline'u placementu. Brak bezpośredniej operacji transformu w oknie nie wyklucza dalszych konsumentów.

Źródła Gamebryo pozostają oracle mechanizmów, nie dowodem formatu świata MindArk, dokładnego ABI klienta, lokalnego placementu ani źródła seeda. Ten przegląd ich ponownie nie otwierał.

## 9. Rekomendowany kolejny run

**Rosetta Value Provenance Review — records-only, zakończony jednym konkretnym projektem eksperymentu.**

Ma odpowiedzieć na trzy pytania z załączonego audytu, używając już zapisanych dowodów i obowiązujących supersessions. Powinien oddzielić:

1. Mechanizm zasilania factory/component dla konkretnej klasy.
2. Pochodzenie aktualnej wartości przy konkretnej gałęzi getter/lookup.
3. Związek tej wartości z definicją, zasobem i statyczną instancją świata.

Nie wymaga ponownego skanu oryginałów. Dostaje kopie źródeł i tożsamości. Dopuszczamy ograniczone doczytanie powiązanych artefaktów z tego samego snapshotu, aby nie opierać projektu EXE na samych narracyjnych raportach. Ma wybrać **jedną** brakującą krawędź i przygotować jej falsyfikowalny kontrakt z rzeczywistą wcześniejszą kotwicą. Jeśli nie ma bezpiecznej kotwicy, ma nazwać dokładny brakujący artefakt, zamiast wymyślać VA lub nowy eksperyment.

To ostatnie przygotowanie wejścia do konkretnego śledzenia producenta, a nie kolejna korekta zamkniętego Placement Probe. Nowy RE wymaga późniejszej decyzji; nie zostanie uruchomiony przez ten prompt.

```text
REVIEW_VERDICT = ACCEPTED_WITH_CORRECTIONS_AND_NARROWING
NUMERIC_VFS_NAME_MATCH = 19/19_IN_EXAMINED_ENUMERATION
EXAMINED_ENUMERATION_SIZE = 61
CLASS_20002_LOADING_MECHANISM = PRESERVED_IN_PRIOR_SCOPE
TABLE10_WRITER_MECHANISM = PRESERVED_CONFIRMED_STATIC_CONDITIONAL
SPECIFIC_RUNTIME_GETTER_VALUE_PRODUCER = UNVERIFIED
WRITE_TO_LATER_GETTER_VALUE_PRESERVATION = NOT_ESTABLISHED
CLASS_20006_EXACT_VALUE_BACKING = UNRESOLVED
MODEL_218757_TO_WORLD_INSTANCE = NOT_ESTABLISHED
HISTORICAL_PLACEMENT = NOT_ESTABLISHED
WORLD_XYZ_RECOVERED = NO
ORIGINAL_GAME_BYTES_READ_THIS_REVIEW = 0
NEW_EXE_RE = NOT_PERFORMED
COMMIT_PUSH = NOT_PERFORMED
CANONICAL_GATE_EFFECT = NONE
NEXT_EXPERIMENT_AUTHORIZED = NO
HARD_STOP = YES
```

## Odtwarzalność tego przeglądu

`export_existing_evidence.py` eksportuje wyłącznie przypięte obiekty Git. `check_names_and_anchors.py` sprawdza hashe kopii i przelicza nazwy/pętle/pointery z zapisanych okien. Żaden nie otwiera oryginalnej gry. Pozostałe wnioski są adjudykacją treści istniejących raportów i supersessions, nie wynikiem uniwersalnego semantic verifiera. Nowe skrypty i raport powstały w jednym kontekście: **SELF_REVIEW**, bez deklaracji niezależnego Desktop postauditu tego pakietu.
