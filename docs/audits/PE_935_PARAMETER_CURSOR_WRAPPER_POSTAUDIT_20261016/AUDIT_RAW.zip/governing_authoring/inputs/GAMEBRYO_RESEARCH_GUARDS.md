# Gamebryo jako pomoc w odzyskiwaniu placementu PE — badanie 2026-10-14

**Wniosek:** główny kierunek załącznika jest zasadny. Oryginalny Gamebryo może pomóc kwalifikować odczyt modeli i rozpoznać konsumenta transformu. Nie dostarcza brakującego powiązania między modelem 218757 a konkretną historyczną instancją Eudorii. Najbardziej praktyczna korekta rekomendacji to wykorzystanie istniejących implementacji NiArk w Niflib oraz sprawdzenie ich zgodności z naszymi zapisanymi granicami, zanim powstanie nowy natywny loader.

## Co zrobiono

Przeczytano załącznik. Ponownie pobrano publiczne źródła Niflib, kod edytora DAoC oraz przypięty raport naszego wcześniejszego runu Gamebryo. Ponownie zahashowano dwa zapisane schematy nifxml i dziewięć plików lokalnych SDK. Sprawdzono konkretne funkcje loadera, transformów i tutoriala Scene Attachment. Odczytano wcześniejsze wyniki kontroli oraz źródło PecNif10Reader.js, bez wykonywania tego czytnika.

11 zapisanych publicznych plików ma potwierdzoną tożsamość Git blob, rozmiar i SHA256. To liczba sprawdzonych tożsamości, nie testów silnika. Dziewięć plików SDK ma świeże SHA256; ich źródeł nie kopiowano do pakietu. SOURCE_IDENTITIES.json rozróżnia publiczne kopie, SDK oraz zapisane dowody. check_sources.py wykonuje skończone kontrole tekstu, XML i arytmetyki bajtów; nie jest dekoderem PE ani testerem natywnego loadera.

Nie czytano oryginalnego Entropia.exe, Models.bnt ani innych danych gry. Nie uruchomiono klienta, SceneGraphPrinter, PyFFI, Niflib ani edytora DAoC. Nie zmieniono repozytorium lub aktywnego kontraktu CMO. Załącznik zawiera historyczną deklarację HEAD; niniejszy research używa dokładnego commitu 3fbe93e, bez nowego zaświadczenia live HEAD repo PE.

## 1. Brak create function: diagnoza trafna, zakres trzeba zachować

Przypięty FINAL_REPORT rozróżnia cztery rzeczy: census 5596 zasobów, podzbiór 4838 NIF 10.1.0.0, rejestr 198 klas bez NiArk oraz cztery natywne próby PE zakończone odmową. Specyficzny komunikat o NiArkAnimationExtraData pochodzi z ujawnionego pomocnika; vendor printer wypisał ogólne Error loading stream. Nie powtarzano tych prób teraz. [Raport runu](https://github.com/SebastianKozlo/eudoria-clean/blob/3fbe93eec04759395223e6677b5040273d29222a/docs/audits/PE_935_GAMEBRYO_ENGINE_ASSISTED_SCENE_INSPECTION_R1_20261009/FINAL_REPORT.md).

W lokalnym NiStream.cpp 1.2 LoadRTTI sprawdza wszystkie nazwy tabeli typów przed tworzeniem obiektów. Brak funkcji create kończy odczyt. Dlatego brak instancji danej klasy nie musi uratować pliku, jeżeli jej nazwa znajduje się w tabeli. Wniosek o odrzuceniu całego tego podzbioru przez niezmieniony rejestr jest prognozą opartą na kodzie i census, nie 4838 wykonaniami.

Nie jest to dowód uszkodzenia zasobów ani niemożności napisania zgodnego loadera. Jest to bariera zgodności stockowego narzędzia z rozszerzeniami gry.

## 2. Najważniejsze uzupełnienie: mamy implementacje, nie tylko opisy PyFFI

PyFFI 7f4404db przypina nifxml f265c564. Ten stary schemat zawiera pięć klas NiArk ExtraData. Sprawdzony master nifxml 970a6238 nie zawiera tych definicji. Gitlink został już ustalony w naszym researchu z 9 października, więc nie należy przedstawiać go jako nowego odkrycia tej sesji. [Schemat przypięty przez PyFFI](https://github.com/niftools/nifxml/blob/f265c56482c728c6877e45d5b5993d3bff83670a/nif.xml).

**Dodatkowo Niflib e2916618 zawiera rzeczywiste Read/Write, obsługę referencji i rejestracje tych pięciu klas.** NiArkTextureExtraData czyta listę pozycji, nazwy, link do NiTexturingProperty i dziewięć surowych bajtów na pozycję. Jest to konkretna podstawa implementacyjna. Niflib nie jest biblioteką Gamebryo i nie można wstawić jego klas bezpośrednio do rejestru NiStream; może być osobnym czytnikiem porównawczym lub źródłem hipotezy formatu. [Reader tekstur](https://github.com/niftools/niflib/blob/e29166183e23c3477fb7e08d4523dd111440947e/src/obj/NiArkTextureExtraData.cpp), [rejestr klas](https://github.com/niftools/niflib/blob/e29166183e23c3477fb7e08d4523dd111440947e/src/gen/register.cpp).

Nie oznacza to pełnej obsługi PCG. Zestaw tych pięciu klas nie obejmuje NiArkBillboardNode ani NiVertexMorphExtraData, odnotowanych w poprzednim census. Osiągnięcie zgodności dla 218757 nie ustanowi zgodności dla wszystkich zasobów.

## 3. Konkretna rozbieżność: historyczny schemat a zapisany parser 218757

Porównano definicje z wcześniejszym MEASUREMENTS.json, bez odczytu oryginalnego NIF. PecNif10Reader.js potwierdza, które prefiksy są odczytywane przed zapisem extStart.

| Typ | Odcinek przewidziany przez publiczny reader | Odcinek zapisany wcześniej dla 218757 | Wniosek |
|---|---|---|---|
| Animation | 16 B po bazowej nazwie dla 10.1 | 16 B po nazwie | Zgodna długość, semantyka nieustanowiona |
| Importer | 41 B po nazwie, int i importer string | 41 B po tym prefiksie | Zgodna długość reszty, nie dowód znaczenia pól |
| ViewportInfo | 13 B po bazowej nazwie | 49 B po nazwie | Rozbieżność 36 B wymagająca rozstrzygnięcia |

Źródła publicznych implementacji: [Animation](https://github.com/niftools/niflib/blob/e29166183e23c3477fb7e08d4523dd111440947e/src/obj/NiArkAnimationExtraData.cpp), [Importer](https://github.com/niftools/niflib/blob/e29166183e23c3477fb7e08d4523dd111440947e/src/obj/NiArkImporterExtraData.cpp), [ViewportInfo](https://github.com/niftools/niflib/blob/e29166183e23c3477fb7e08d4523dd111440947e/src/obj/NiArkViewportInfoExtraData.cpp).

**49 B ma autorytet wcześniejszej decyzji parsera z odziedziczoną granicą bloku.** Nie ustanawia samoistnie prawdziwego layoutu PCG ani błędu publicznego readera. Możliwe są różnica formatu, niepełna specyfikacja lub błędna wcześniejsza granica. Nie interpretowano dodatkowych 36 B jako transformu, pozycji ani macierzy.

Drugi szczegół zapobiega fałszywemu zgłoszeniu błędu: publiczny reader tekstur traktuje fragment jako dwa inty, byte i int count; nasz reader odczytuje trzy DWORD-y i byte, wyjmując count z 24 bitów. W syntetycznym nagłówku z count=14 obie reprezentacje są zgodne. Dla count=2^24+14 już nie są. To kontrola grupowania bajtów, nie wykonanie produkcyjnego parsera ani dowód używania takiego count przez PE. Nie wolno porównywać wyłącznie nazw pól i ogłaszać zgodności lub niezgodności.

## 4. Dlaczego proste stuby klas nie wystarczą

RegisterLoader istnieje w nagłówkach zarówno SDK 1.1.2, jak i źródłach 1.2. Jest więc techniczny punkt rozszerzenia. Jednak LoadBinary kolejnych obiektów konsumuje wspólny strumień; po nim następują linkowanie i post-link. Nie wystarczy zwrócić pustego obiektu pod nazwą NiArk.

W badanym schemacie długości bloków w nagłówku dotyczą późniejszych wersji niż 10.1. Sam nagłówek 10.1 nie daje ogólnej instrukcji, ile bajtów nieznanego body należy przeskoczyć. Błędny reader jednego rozszerzenia może przesunąć odczyt następnej geometrii, mimo że fabryka przestała zgłaszać błąd.

Bezpieczna kwalifikacja wymaga zgodności prefiksu, zużycia bajtów, liczników, linków i końca grafu. Opaque zawartość może zachować nieznaną semantykę, jeśli jej granica jest niezależnie uzasadniona. Sam EOF-exact po wyszukiwaniu granic nie jest pełnym dowodem poprawności.

## 5. DAoC: analog potwierdzony w kodzie edytora, z ważnym szczegółem wysokości

Zamiast opierać się wyłącznie na poradniku, odczytano Zone.cs i Objects.cs projektu Uthgard Zone Editor na commicie 01302420. Kod ładuje osobno nifs.csv i fixtures.csv. Wpis NIF zawiera ID i nazwę pliku. Fixture zawiera własne ID, odwołanie do wpisu NIF, pozycję, skalę oraz opcjonalny obrót o osi. To bezpośredni przykład rozdziału definicja–instancja w narzędziu dla DAoC. [Zone.cs](https://github.com/thekroko/uthgard-opensource/blob/01302420e4fd3b513eee88a22002ed7877797616/zoneeditor-oss/HMapEdit/Engine/Zone.cs).

W getterze Fixture.Z opcja OnGround powoduje pobranie wartości z HeightMap według X/Y. Gdy opcja jest wyłączona, getter oddaje zapisane m_Z. Edytor wczytuje także skalę i kąt z osią zamiast wymagać trzech kątów Eulera. To użyteczna kontrola przeciw założeniu, że jedynym poprawnym rekordem placementu jest ID obok sześciu floatów. [Objects.cs](https://github.com/thekroko/uthgard-opensource/blob/01302420e4fd3b513eee88a22002ed7877797616/zoneeditor-oss/HMapEdit/Engine/Objects.cs).

Granica dowodu: jest to kod społecznościowego edytora, nie odzyskany oryginalny klient DAoC ani PE. Nie przenosimy plików CSV, współczynnika 256, osi lub tego algorytmu wysokości do Eudorii. Podobieństwo silnika nie ustanawia formatu danych MindArk.

## 6. Co naprawdę robi Gamebryo ze światem

Lokalny tutorial Scene Attachment wczytuje WORLD.NIF, odnajduje nazwany węzeł, wczytuje OBJECT.NIF i dołącza obiekt. To narzędzie może otworzyć przygotowaną scenę; nie wyszukuje samo brakującej bazy świata. Nazwa WORLD.NIF w tutorialu nie oznacza, że taki plik musi istnieć w PE.

NiAVObject w lokalnym SDK przechowuje local transform. SetTranslate zmienia tę wartość. Win32 UpdateWorldData składa transform rodzica z lokalnym; przy braku rodzica przyjmuje lokalny jako world. Dlatego wynik world w samodzielnie załadowanym modelu może oznaczać jedynie przestrzeń tego grafu. Update nie znajduje brakujących współrzędnych Eudorii.

Praktyczny łańcuch badawczy pozostaje następujący:

```text
źródło danych instancji
  -> konkretna instancja i jej definicja
  -> właściwy model, np. 218757
  -> transform instancji lub nadrzędnego sektora
  -> wewnętrzne transformy NIF / geometria
  -> wynik renderera
```

NIF może przechowywać rozbudowaną scenę, lokalne układy wielu części albo zasób pojedynczego obiektu. Odczyt tego układu jest wartościowy, lecz zewnętrzny anchor sektora/instancji wymaga osobnego dowodu. Gamebryo nie wyklucza kanału plików, cache, skryptu, procedury ani sieci.

## 7. Właściwa kolejność wersji i pracy

Końcową rekomendację załącznika doprecyzowałbym:

1. **Gamebryo 1.1.2:** najbliższy posiadany punkt odniesienia rodziny wskazywanej przez importer PE. Nie exact-build proof klienta.
2. **Gamebryo 1.2:** dostępne źródła wyjaśniające algorytmy i mechanizm fabryki. Offsety, vtable i ABI wymagają własnej kwalifikacji.
3. **Historyczny Niflib/PyFFI:** kandydat formatu rozszerzeń, z rozbieżnościami ujawnionymi powyżej. Te projekty mogą dzielić schemat, więc ich zgodność nie jest niezależnym odzyskaniem semantyki NiArk.
4. **Gamebryo 2.3/2.6:** porównanie architektury. W odczytanym NiStream.cpp 2.6 minimum to 10.1.0.114, wyższe od PE 10.1.0.0. Nie oznacza to niemożności narzędziowej konwersji, ale podmiana nagłówka nie jest zgodną konwersją.

Rosetta powinna rozdzielać strukturę bajtów, tożsamość obiektu, znaczenie pól oraz źródło historyczne. Three.js może konsumować wynik zgodnego readera przez SceneIR; nie wymaga to uruchamiania oryginalnego runtime Gamebryo w przeglądarce. Samo wyrenderowanie modelu nie odtwarza gameplay, postaci, sieci ani rozmieszczenia.

## 8. Propozycja po zakończeniu aktywnego runu

Najpierw audyt rzeczywistego wyniku CMO Single Word Source. Znalezienie źródła jednego słowa nie identyfikuje historycznego budynku. Nazwa MovableObject również nie wystarcza do wykluczenia udziału tej ścieżki w obiektach statycznych.

Osobny eksperyment NiArk miałby konkretne pytanie: czy dla jednego przypiętego zasobu 218757 publiczny reader i nasz reader przypisują identyczne zakresy bajtów oraz referencje czterem użytym rozszerzeniom? Priorytetem byłaby rozbieżność ViewportInfo 13/49, nie pełne portowanie SDK. Warunki: zachować oryginał; rozliczyć niezgodności; nie zgadywać pól; użyć kontroli złego count, przesuniętej granicy i błędnego linku; ewentualny rozszerzony oracle jawnie oddzielić od stockowego. To propozycja, nie kontrakt lub dispatch.

**Nie należy uzależniać poszukiwania lokalizacji od stuprocentowego rozpoznania wszystkich NiArk.** Do źródła placementu może prowadzić krawędź w kodzie lub rekordach niezależna od pełnego shader/viewport decode. Użyteczność naprawy readera zależy od konkretnej blokującej luki.

```ini
RESEARCH_STATUS = COMPLETE_IN_DESCRIBED_SOURCE_SCOPE
PUBLIC_SOURCE_IDENTITIES = VERIFIED_11_OF_11
LOCAL_SDK_FILE_IDENTITIES = MEASURED_9
NIFLIB_NIARK_READER_AND_REGISTRY_SUPPORT = CONFIRMED_FOR_PINNED_FIVE_CLASSES
PE_NIARK_BYTE_COMPATIBILITY = NOT_QUALIFIED_BY_THIS_RESEARCH
VIEWPORT_13_VS_49 = UNRESOLVED_COMPARISON_FINDING
DAOC_TO_PE_FORMAT_TRANSFER = NOT_ESTABLISHED
NEW_ORIGINAL_GAME_BYTES_READ = 0
NATIVE_ENGINE_EXECUTION = NOT_PERFORMED
ACTIVE_CMO_CONTRACT_MODIFIED = NO
MODEL_218757_WORLD_INSTANCE_JOIN = NOT_ESTABLISHED
HISTORICAL_PLACEMENT = NOT_ESTABLISHED
WORLD_XYZ_RECOVERED = NO
REPOSITORY_MODIFIED = NO
COMMIT_PUSH = NOT_PERFORMED
NEXT_EXPERIMENT_AUTHORIZED = NO
```
