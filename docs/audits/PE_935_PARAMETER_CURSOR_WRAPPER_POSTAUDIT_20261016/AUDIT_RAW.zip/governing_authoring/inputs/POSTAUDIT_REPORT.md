# Postaudyt PARAMETER_RECORD_INGRESS_R1 — 16.10.2026

**Werdykt: PARTIAL_PASS.** Rdzeń receiver/argument/K pozostaje potwierdzony jako `CONFIRMED_STATIC_CONDITIONAL_IN_EXAMINED_MODEL`. Pełne compliance procesu jest `NOT_ESTABLISHED`. Wymagane są korekty opisu lokalnego wariantu i oceny procesu; nie podtrzymuję szerokiego zapewnienia „wszystkie twierdzenia naukowe i retencja bez ustaleń”.

Audyt jest `ADVISORY_PRE_QUALIFICATION`; terminal runu pozostaje `PARTIAL`. `CANONICAL_GATE_EFFECT=NONE`, `NEXT_EXPERIMENT_AUTHORIZED=NO`, `HARD_STOP=YES`. Żadnych napraw w audytowanym pakiecie nie wykonano. Zewnętrzny postaudyt jest zakończony w tym osobnym katalogu; historyczne `PENDING` we frozen package pozostaje niezmienione.

## Tożsamość, metoda i granice

Audytowany run: `PE_935_PARAMETER_RECORD_INGRESS_R1_20261016`.

Root źródłowy: `C:\Users\User\Documents\ChatGPT\PE\PE_PARAMETER_RECORD_INGRESS_R1_20261016\opencode_output`.

Kontrakt: **15684 B / 9C3325406DD28D6F1F56295F7ECC27728D57DB31363F5E294297E487943B63A2**.
INPUT_PINS: **5676 B / 908B9CCC07153800E0D4DD3D464E0D396BABEF08B0707EA05EB67E98713B7C86**.

Własny re-hash: 11/11 kopii + kontrakt + INPUT_PINS = **13/13 zgodnych**. PROMPT_ROOT/opencode_output obecnie nie istnieje. Nie odtwarzam historycznego absent-check przed pierwszym utworzeniem; jego zapis pozostaje dowodem historycznym.

Pracowały trzy konteksty: główny pomiar oraz odrębne przeglądy twierdzeń i procesu. Każdy miał wyłącznie zapisane artefakty/inputs. Żaden nie otwierał EXE, ciał callee, innych runów, repo ani sieci. Nie wykonano decoderów lub historycznych narzędzi; nie uruchamiano ponownie C1–C4. Zapisane kontrole sprawdzono przez odczyt kodu, mutantów, wyników i anchorów.

## Własne pomiary

| Kontrola | Wynik |
|---|---|
| Manifest | 73 wiersze / 74 pliki / 676422 B; pełna bijekcja, 0 błędów SIZE/SHA |
| Manifest identity | 7425 B / C689D9F07E0B3825E549A8C298F7D3B46BABC8D8FEF5460996A7DAEFE3A5DBB3 |
| Parse JSON/JSONL | 46 PASS + 1 znany pusty capture; zero nowych błędów, duplicate keys i NaN odrzucane |
| Bufory okna | 2×434 B, byte-identyczne; SHA256 6A7D19DB23BC960761715D27084E185E876577736787BFA7AAADCDAEF32DAD0F |
| Zapisany nagłówek PE | 4096 B; własny parse PE32/i386, ImageBase 0x400000, unikalne RAW .text; offset 0x452750 = 4532048 |
| PATH_A/roster/PATH_B | własny parse transkryptu A, 3 continuation lines; 133/133 wiersze zgodne z buforem, ciągłe 434 B |
| Cele | 31 bezpośrednich celów rekomputowanych z bajtów + 1 forma CALL EAX; nie 32 rozwiązane adresy callees |
| Callsite units | 12 = 11 bezpośrednich E8 + 1 FF D0; zgodne z listą budżetową |
| Provenance | wszystkie raw bytes w 16 wierszach zgodne z rosterem i buforem |
| Standing | finalne 19/19 dokładnie zgodne; historyczne 20/20 zachowane verbatim, w tym PENDING |
| Ledger | 24 wpisy; wszystkie 3 jawne hash chains prefixów zgodne |
| Relokacja | PRE=POST 49/49; obecnie 47/49 pod starymi nazwami + oryginalny REPORT zachowany jako draft + oryginalny ledger jako prefix |
| Stan przed/po audycie | 74/74 pliki pakietu i 13/13 pinów byte-unchanged |

Znany pusty plik to `attempts/ab_compare_stdout.json` (0 B). Jest wiernym capturem nieudanej próby, nie nowym błędem JSON dokumentu. Mtime żadnego pliku nie jest późniejszy niż manifest. Ten pomiar nie dowodzi całej historii zapisów; obecna tożsamość i brak zmian przez audyt są niezależnie sprawdzone.

11 targetów CALL E8 nie jest zapisanych przez PATH_B jako pola target/imm; są liczone arytmetycznie z jego zapisanych raw bytes przez t05v2. Kod jawnie to ujawnia. Nie traktuję tego jako niezależnego sprawdzenia całej semantyki operandów przez dwa dekodery.

## PRI-PA-01 / P2 — valid-fail nie jest ścieżką zerowania K

Lokalizacje: `EVIDENCE.json:42–43`, `/symbols_separately_typed/K_dword_to_ebp/{guards,zeroing_branch}`; `:146`, `/provenance_rows/6/finding`; `:275`, `/variants_qualified/k_guard_fail`; `REPORT.md:34`.

Opis tworzy koniunkcję `valid!=0 AND offset+4<=size`, a następnie mówi o K=0 „when guards fail”. Bajty ustanawiają dwa różne warianty:

| Warunek | Instrukcje / cel | Dalszy przebieg |
|---|---|---|
| valid=0 na wejściu iteracji | MOV AL,[ESI+11] @0x852813; TEST AL,AL @0x852816; JE @0x852818 → 0x8528CF | wyjście z pętli; brak zerowania K, alokacji, init i selected CALL |
| valid!=0, test size niezdany | CMP EDX,[ESI+8] @0x852824; JA @0x852827 → 0x852839 | XOR EBP,EBP; clear valid @0x85283F; dalszy przebieg z K=0 |
| valid!=0, test size zdany | MOV EBP,[ECX+EAX] @0x85282B | K z data+offset; zachowanie na PUSH warunkowe na ABI |

To korekta lokalnej reachability i opisu provenance, nie dowód błędnych bajtów lub cofnięcie całego szwu. W wybranym przebiegu dochodzącym do CALL identyfikacje R/C/K pozostają wsparte. Ogólne sformułowanie musi zostać zawężone do **size-fail po valid loop-head**.

Arytmetyka guardu jest 32-bit modulo. Brak odrębnego dowodu no-wrap nie jest tutaj nowym P2: raport nie deklaruje OOB safety. Nie przypisuję rzeczywistemu cursorowi złego offsetu ani nie twierdzę, że nastąpił nieprawidłowy odczyt.

## PRI-PA-02 / P2 — korekta zapisanego błędu po limitcie ma rounds0

§7 kontraktu (`OPENCODE_PARAMETER_RECORD_INGRESS_R1.md:130`) liczy każdą poprawę błędu zapisanej własnej wersji, w tym w materializacji; nowa nazwa ani dispatch nie zerują licznika. Pierwszy zapis nowego raportu jest wyjątkiem, lecz sprostowanie jego błędu nim nie jest.

`REPORT_v1_draft.md:90` zawiera `HARD_STOP = YES.`. Final `REPORT.md:124–126` jawnie nazywa to błędem P3-3 i mówi o jego poprawieniu; fenced block kończy się poprawnym `HARD_STOP = YES`. Ledger0022 powtarza „P3-3 corrected” przy `repair_round_consumed=0`.

Runda2 była już zamknięta w0020 o11:38:50Z jako relokacja wrong-root + zapis supersessions. Korekta raportu nastąpiła w0022 między12:47:23 a12:51:01Z. Nie jest częścią zamkniętej rundy relokacyjnej. Zachowanie draftu spełnia retencję tego dokumentu, ale nie wykazuje zgodności z limitem poprawek.

**Nowe ustalenie dotyczy kwalifikacji rounds0; sama kosmetyczna P3-3 była już ujawniona.** Według literalnego §7 doszła co najmniej jedna korekta po wyczerpaniu2/2. Nie rekonstruuję dowolnej większej liczby rund, nie zmieniam historycznego budżetu i nie przyznaję retroaktywnego wyjątku. PARTIAL pozostaje właściwym terminalem, a zapewnienie o wszystkich budżetach „w limitach” nie jest podtrzymane.

## PRI-PA-03 / P2 — późniejszy superset nie zachowuje pierwszego wyniku

Zdarzenie jest już ujawnione w `ATTEMPT_LOG.jsonl:17/process_disclosure`. `tools/t08_json_validate_all.py:72–74` zawsze otwiera `records/JSON_VALIDATION.json` w trybie `w`. Drugie wykonanie nadpisało pełny wynik pierwszej walidacji29 plików wynikiem33 plików.

Zachowany pierwszy stdout ma176 B: `files_checked=29, pass=27, fail=2` oraz dwie nazwy failed. Nie zawiera29 rekordów per-file ani timestampów narzędzia. Bieżący detal ma5127 B i33 rekordy drugiego wykonania. W całym zapisanym korpusie JSON nie znaleziono pierwszego obiektu z29 results; agent procesu przeszukał też pozostałe teksty.

To nie tylko równoważny nowy widok tych samych danych: `attempts/json_validate_stdout.json` ma w pierwszym podsumowaniu **FAIL**, a w drugim detalu **PASS**. Ponowna walidacja supersetem dowodzi późniejszego stanu; nie przechowuje wcześniejszego wyniku.

§7 kontraktu (`:128`) zabrania nadpisywania wyników. Klasyfikacja z `qc_fresh/QC_FRESH_REVIEW.json:114,189` jako nieszkodliwego supersession szczegółów nie spełnia tej retencji. **Nowa jest ocena compliance, nie odkrycie overwrite.** PRE/POST49/49 powstało po tej utracie i nie może jej zamknąć. Oryginalny rozmiar/hash pełnego wyniku run1 pozostaje nieustanowiony. Nie fabrykuję brakującej wersji.

To ograniczenie historii jednego wyniku procesu; obecna składnia JSON, zachowane bufory i główny szew nie są przez nie obalone.

## Pozostałe obserwacje i znane findings

- **PRI-PA-O1 / P3:** ledger0022 zapewnia, że wszystkie inne pola czasu materializacji są bezpośrednio mierzone. Ledger0023 jawnie oznacza swój time_start jako approximate. Lokalna dysklozura istnieje; zbiorcze zapewnienie jest zbyt szerokie. Nie wyprowadzam nowej fałszywej daty ani intencji.
- **PRI-PA-O2 / P3:** w przekazanym handoffie JMP@0x852900 nazwano back-edge pętli. `EB D0` idzie do wspólnego epilogu@0x8528D2; rzeczywisty loop back-edge to `JB @0x8528C9 → 0x852813`. Roster i EVIDENCE row15 są poprawne. Jedno zdanie REPORT myli callsite init0x85287F z target0x852DC0, poprawnym w pozostałych miejscach; TEST@0x8528A to typo właściwego0x85288A.
- **Znany P2-1 pozostaje OPEN:** własny odczyt potwierdził sprzeczności0006/0014/0017 z cytowanymi timestampami narzędzi. Nie są one nowym odkryciem tego audytu.
- **DISCLOSURE-M1 jest obecna w0022:** rzeczywiste t0=12:47:23Z, zapis=12:51:01Z, delta218s. Nie została retroaktywnie poprawiona. Samo ujawnienie luki nie ustanawia zgodności pierwotnego „measured immediately” z chwilą zapisu.

Wniosków o advance/release/freshK nie należy rozszerzać na dowiedzione skutki opaque callees lub różne wartości w kolejnych iteracjach. RET4 bezpośrednio ustanawia cleanup4; dokładna liczba parametrów i thiscall są opisem konwencji w modelu. C=[entryESP+4] ma odrębny dowód z prologu. Zapis O na stosie jest bezpośredni; późniejsze odtworzenie wymaga modelu cleanup. Nie traktuję hipotetycznego memory-clobbera jako wykrytego defektu.

## Zachowany wynik lokalnego pytania

| Element | Ustalenie |
|---|---|
| Receiver selected CALL@0x8528B2 | ECX:=EDI; EDI z R=EAX po init CALL@0x85287F→0x852DC0; tożsamość warunkowa na preserved EDI przez opaque CALL |
| Argument | PUSH ESI@0x8528AF; ESI z C=[entryESP+4]; zachowanie C na PUSH warunkowe na ABI |
| K | DWORD z bufora C.data na bieżącym offsecie w ścieżce read; osobno K=0 w size-fail; PUSH EBP jako pierwszy stack arg init warunkowo na ABI |
| V | EAX z [[EDI]+4], użyty jako adres kodu CALL EAX; rzeczywisty target/effects NOT_ESTABLISHED |
| A/R | neither equality nor inequality established |
| Source/world | medium UNKNOWN, pola bez semantycznej promocji, joins/placement NOT_ESTABLISHED, XYZ=NO |

Łączny zapisany odczyt oryginału sumuje się do16036708 B=limitu. Lista callsite units ma12, states16. To weryfikacja zapisanych list i arytmetyki; nie nowe świadectwo wszystkich historycznych operacji I/O. Żaden nowy oryginalny odczyt nie został wykonany.

## Zakończenie i artefakty

Postaudyt zakończony osobno, przy zachowaniu frozen source. Nowe ustalenia nie autoryzują napraw ani kolejnego micro-runu. Nie przygotowano następnej krawędzi, nie otwierano FUN_00852DC0 lub innych callees, nie zmieniono repo/milestone.

`VERDICT=PARTIAL_PASS`; `FULL_PROCESS_COMPLIANCE=NOT_ESTABLISHED`; `CLAIM_RECORD_CORRECTIONS_REQUIRED=YES`; `CANONICAL_GATE_EFFECT=NONE`; `HARD_STOP=YES`.

[Pomiary JSON](C:/Users/User/Documents/Codex/2026-10-13/files-pasted-by-the-user-wszystko/outputs/PARAMETER_RECORD_INGRESS_POSTAUDIT_20261016/MEASUREMENTS.json) · [Ustalenia JSON](C:/Users/User/Documents/Codex/2026-10-13/files-pasted-by-the-user-wszystko/outputs/PARAMETER_RECORD_INGRESS_POSTAUDIT_20261016/FINDINGS.json) · [Skrypty i notatki recenzentów](C:/Users/User/Documents/Codex/2026-10-13/files-pasted-by-the-user-wszystko/outputs/PARAMETER_RECORD_INGRESS_POSTAUDIT_20261016/AUDIT_RAW.zip)

Pomiar czasu utworzenia tego raportu UTC: 2026-10-16T13:29:16.620836+00:00.
