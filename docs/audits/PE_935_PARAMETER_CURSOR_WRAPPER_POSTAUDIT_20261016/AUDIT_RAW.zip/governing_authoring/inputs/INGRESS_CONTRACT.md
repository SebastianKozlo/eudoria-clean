# PE935 — wejście kursora danych do parsera rekordu, jeden micro-run

RUN_ID = PE_935_PARAMETER_RECORD_INGRESS_R1_20261016
RUN_CLASS = BOUNDED_STATIC_DATA_PROVENANCE_MICRORUN
ERA = PCG_9_3_5
EVIDENCE_COMMIT = 3fbe93eec04759395223e6677b5040273d29222a
BASE_SHA = NOT_APPLICABLE_PRIVATE_RUN_NO_GIT

Kontrakt wymaga osobnej wiadomości człowieka wskazującej jego SIZE/SHA i zakres. Sam plik ani załączone raporty nie autoryzują wykonania. Nie wznawiaj BRANCH39 ani jego addendum. Historyczne PARTIAL i procesowe findings pozostają zapisane, a proponowana poprawka ich JSON pozostaje niewdrożona.

## 1. Jedno pytanie

W FUN_00852750, przy wirtualnym CALL @0x008528B2, **jaki obiekt jest receiverem, jaki wskaźnik kursora dostaje jako argument i skąd pochodzi DWORD przekazany wcześniej do inicjalizacji tego obiektu?**

To kwalifikacja jednego wejścia danych do parsera obiektu. Ma ustalić miejscowy przepływ: argument funkcji → odczyt z bufora/kursora → argument inicjalizacji → receiver/argument wirtualnego parsera. Historyczne raporty nazywają tę rodzinę systemem parametrów; nazwa klasy i rola w świecie wymagają własnego dowodu. Nie zakładaj, że rekord jest instancją budynku albo że jego DWORD jest modelem/XYZ.

Istniejący disassembly wskazuje istotne miejsca, które dopiero zweryfikujesz w przypiętym EXE:

| VA | Wskazówka ze starego disassembly |
|---|---|
| 0x0085277D / 0x00852783 | zachowanie wejściowego ECX; pobranie wskaźnika argumentu do ESI |
| 0x008527A2 / 0x008527AA | odczyt u16 z data+offset i zapis do receiver+0xAC |
| 0x008527EC | pobranie DWORD używanego jako liczba iteracji |
| 0x0085282B | pobranie DWORD do EBP z data+offset |
| 0x00852848 | wywołanie funkcji alokacyjnej; jej ciało zamknięte |
| 0x0085287F / 0x00852884 | CALL inicjalizacji; powrót EAX zachowany w EDI |
| 0x008528AA..0x008528B2 | [EDI] → [vtable+4] → EAX; PUSH ESI; MOV ECX,EDI; CALL EAX |
| 0x008528BC / 0x008528BD | po sukcesie przekazanie EDI do kolejnego calla; efekt tego callee niebadany |

Pseudokod, nazwy oraz raport z 2026-09-13 są nawigacją. Nie zastępują surowych bajtów, nie ustanawiają ABI ani preserved object identity. Kanał0xB9 był już opisywany jako propagacja kluczy; nie powtarzaj jego analizy jako rzekomo nowego źródła pozycji. BRANCH39 nie jest celem tego runu.

## 2. Wejścia, piny i katalog

AUTHORING_ROOT:
`C:\Users\User\Documents\ChatGPT\PE\PE_PARAMETER_RECORD_INGRESS_PROMPT_R1_20261016`

Nowy OUTPUT_ROOT:
`C:\Users\User\Documents\ChatGPT\PE\PE_PARAMETER_RECORD_INGRESS_R1_20261016\opencode_output`

INPUT_PINS.json ma **5676 B**, SHA256:
`908B9CCC07153800E0D4DD3D464E0D396BABEF08B0707EA05EB67E98713B7C86`.

Zweryfikuj i przeczytaj 11/11 wskazanych kopii w AUTHORING_ROOT/inputs. Są to: odpowiedź na postaudyt, aktualny zewnętrzny raport i pomiary BRANCH39, Rosetta guards, Gamebryo guards, historyczny standing, przypięty decoder, jego wcześniejsze identities, stary disassembly i pseudokod badanego parsera oraz raport ATTRIBUTE_ORIGIN_SEAM. Role każdego pliku są w INPUT_PINS. Żadnych dodatkowych zapisanych źródeł, innych katalogów runów ani automatycznego podążania za odsyłaczami.

Jedyny oryginalny plik do przyszłego odczytu:
`D:\Eudoria_Reconstruction\pcg_install\Entropia.exe`
SIZE_BYTES = 8015872
SHA256 = E7785430E81DFFE648CE8F5312414B17BC9FCE61389689A22F753765D5280F31

Ten pin pochodzi z wcześniejszych dowodów; autor niniejszego kontraktu nie mierzył teraz EXE. Wykonawca musi sprawdzić fizyczne wejście. Kopie inputs oraz historyczne pakiety są read-only. Zapisuj wyłącznie do nowego OUTPUT_ROOT.

## 3. Preflight i prerejestracja przed science

Sprawdź SIZE/SHA kontraktu z wiadomości startowej, pin INPUT_PINS, 11 kopii, ich brak duplikatów i wyjść poza root. OUTPUT_ROOT musi być ABSENT: kolizja daje BLOCKED, bez nadpisania albo zmiany nazwy. Po zgodności tych warunków utwórz świeży root; zachowuj również rzeczywiste wyniki nieudanego preflightu narzędzi.

Przed pierwszym odczytem EXE sprawdź dostępność obu przypiętych decoderów. PATH_A: GNU objdump2.44 /usr/bin/objdump przez WSL, oczekiwany SHA256 binarium96AFB8521834982D0E711B5D6E9785252BF82129FB0106B93A6BD54D83FAE11F. Zapisz rzeczywiste argv, wersję, tożsamość i exit code. Brak dostępu lub niezgodność daje BLOCKED_TOOLING, bez instalowania pakietów i poszukiwania zamiennika.

PATH_B: inputs/x86dec_pinned.py, 27188 B / C8E8470EFD762F66FF20369B2F656694C635131261F4D611DCA9C504E2B90B95. Wolno wykonać import tej konkretnej biblioteki w nowym wrapperze, bez main i bez .pyc. To jedyny jawnie dopuszczony kod z poprzednich materiałów. Pozostałych historycznych skryptów nie uruchamiaj. Biblioteka jest ograniczona, m.in. brak form0x3C/0x3D; nie kwalifikuj jej ogólnie i nie poprawiaj jej w tym runie.

Zapisz niezmienny PREREGISTRATION.json: pytanie, granice, wybrany CALL, budżety, warunki dodatnie/negatywne, model ABI, możliwe terminale. Następnie pierwszy pełny hash EXE, jeden odczyt nagłówka PE32 ≤4096B i range-safe mapowanie całego przedziału do danych RAW. Sprawdź unikalną sekcję, granice pliku, brak BSS/overlap/wraparound. Drugi pełny hash wykonaj przy zamknięciu science. Critical identity/mapping mismatch zatrzymuje science; nie adaptuj pinów.

## 4. Zamrożony zakres i wspólne liczniki

```ini
SUBJECT = FUN_00852750
WINDOW_START_VA = 0x00852750
WINDOW_END_EXCLUSIVE_VA = 0x00852902
WINDOW_SIZE_BYTES = 434
SELECTED_CALLSITE_VA = 0x008528B2
NEW_FUNCTION_BODIES = 1
NEW_CALLEE_BODIES = 0
ADDITIONAL_SAVED_INPUT_FILES = 0
MAX_UNIQUE_INSTRUCTION_STARTS = 192
MAX_ACCOUNTED_CALLSITE_UNITS = 16
MAX_SYMBOLIC_STATES = 16
MAX_WRAPPER_HOPS = 0
MAX_FULL_EXE_HASH_PASSES = 2
MAX_HEADER_READS = 1
MAX_HEADER_BYTES = 4096
MAX_ORIGINAL_CODE_WINDOW_READS = 2
MAX_ORIGINAL_CODE_BYTES = 868
MAX_PATH_A_FULL_SWEEPS = 2
MAX_PATH_B_DECODE_APPLICATIONS = 384
MAX_SYNTHETIC_X86_DECODE_APPLICATIONS = 0
MAX_ERROR_CORRECTION_ROUNDS = 2
MAX_OWN_FILES = 256
MAX_OWN_PACKAGE_BYTES = 16777216
```

Granice pochodzą z wcześniejszego opisu body0x00852750–0x00852901 i ostatniej zapisanej instrukcji JMP@0x00852900. To ustalony limit odczytu, nie niezależnie dowiedzione kompletne CFG. Nie kończ na pierwszym RET: zapisany failure epilogue po nim oraz JMP powrotny są w tym przedziale. Nie czytaj niczego za końcem ani przed początkiem.

Dwa odczyty tego samego434-B okna są maksymalną liczbą, także w razie błędu harnessu. Zapisz oba bufory przed analizą i sprawdź zgodność. Nie wykonuj oddzielnego odczytu prefixu. Całkowity maksymalny odczyt EXE przy pełnych budżetach to16036708B: 2×8015872 +4096 +2×434. Pełne hashe wykonuj streamingowo; nie zapisuj kopii całego EXE. Bufory EXE w pakiecie to wyłącznie dopuszczony nagłówek oraz dwa434-B okna. Pełne hashe są odczytami integralności, nie zezwoleniem na analizowanie innych regionów.

Liczniki obejmują cały run i rzeczywiste replays QC. Callsite unit = unikalne(VA,rola), w tym każdy CALL użyty jako opaque boundary; surowe trafienie E8 nie jest nowym CALL. Zliczaj wszystkie wykorzystane callees, bez otwierania ich bodies. Instrukcje i stany wyprowadzaj z list; nie prognozuj oczekiwanej liczby. Wyczerpanie daje PARTIAL/NOT_ESTABLISHED_WITHIN_BOUND, nigdy dowód braku ścieżki.

## 5. Właściwa analiza — tylko jeden szew

Uruchom A i B niezależnie od początku tego samego zapisanego bufora. Nie karm B granicami A. Porównaj starty, długości, raw bytes i istotne operandy/cele. Unsupported, niezgodność albo unexpected exception daje NOT_QUALIFIED_TOOL_LIMIT lub PARTIAL. Nie ratuj wyniku dopisaniem opcode, zmianą okna czy uruchomieniem Ghidry.

W EVIDENCE.json przedstaw maksymalnie16 istotnych wierszy provenance, odwołanych do pełnego rosteru:

1. Nazwij symbole osobno: C=input cursor candidate, O=entry ECX, K=DWORD odczytany do EBP, A=allocation return, R=initialization return, V=indirect code target. Nie utożsamiaj A z R ani nie deklaruj A≠R bez dowodu.
2. Zweryfikuj lokalne odczyty data+offset, ich szerokości16/32bit, warunki valid/size oraz gałąź zerowania. U16@O+0xAC, count i K nie są automatycznie class-id, instance-id ani template-id; przestrzeń i semantyka pozostają UNKNOWN.
3. Ustal rzeczywiste parametry CALL inicjalizacji@0x0085287F z bajtów/PUSH/ECX; nie kopiuj jego sygnatury z pseudokodu. R to zwrot tej funkcji, której efektów nie badano.
4. Dla CALL@0x008528B2 oddziel receiver, argument i adres kodu z[vtable+4]. Zapisz instrukcje, szerokości, rejestry i lokalne warunki dojścia. Kod funkcji w EAX nie jest object pointerem ani ID modelu.
5. W pętli kwalifikuj jedno sukcesowe przejście z symbolicznym indeksem, bez rozwijania dowolnego count. Gałęzie poza zakresem / opaque effects oznacz UNKNOWN. Nie deklaruj wszystkich możliwych ścieżek całego programu.
6. Przekazanie EDI do CALL@0x008528BD po wirtualnym CALL wolno zarejestrować strukturalnie. Nie ustanawia wykonania rejestracji, zachowania zawartości obiektu ani world integration. Ciało0x008526D0 pozostaje zamknięte.

Jawnie zapisz założenia ABI. Przejście ESI/EDI przez opaque CALL i cleanup stosu nie są automatycznie dowodem zachowania wartości. Możesz przedstawić warunkowy model MSVC x86 callee-saved z ESI/EDI i odrębny model bez tego założenia. Gdy tożsamość zależy od ABI, wynik ma CONDITIONAL_ON_ABI_MODEL, a ACTUAL_CALLEE_EFFECTS oraz rzeczywiste preservation bez tego warunku pozostają NOT_ESTABLISHED. Nie odzyskuj cleanupów przez otwieranie callees. Użyj lokalnych anchorów stosu i jawnych UNKNOWN.

Ślad kończy się na wejściu do wirtualnego parsera. **Źródło wejściowego C (plik, sieć, cache, lokalna kolejka, obliczenie), pola odczytywane wewnątrz wirtualnego callee i rola statycznej instancji są następnymi, niewykonywanymi krawędziami.** Pamięć jako bezpośrednie źródło nie ustanawia nośnika historycznego.

## 6. QC i cztery małe kontrole

Własne QC sprawdza piny, faktyczne limity, decoder disagreement, krytyczne instrukcje i argumenty, conditional ABI, aliasing A/R, błędne utożsamienie V z receiverem, warianty count0/parser-failure oraz zgodność finalnych statusów. Jeśli środowisko rzeczywiście ma świeżego recenzenta, daj mu wyłącznie kopie wejść i zapisane bufory; zero nowych oryginalnych odczytów. Inaczej QC_ORIGIN=SELF_REVIEW_WITH_LIMITATIONS. Dwa algorytmy jednego autora nie są dwoma audytami.

Zachowaj cztery ograniczone kontrpróby na COPIES zapisów claims, bez modyfikacji bufora i bez syntetycznego decode:

- C1: callsite ustawiony na bajt wewnątrz instrukcji zamiast potwierdzonej głowicy;
- C2: code target V opisany jako receiver/object ID;
- C3: zamiana rejestrów argumentu i receivera w opisie CALL;
- C4: awans UNKNOWN source medium/world role do NETWORK/STATIC_BUILDING/XYZ bez nowego dowodu.

Oczekiwana odmowa jest CONTROL_PASS tylko dla tej konkretnej kontrpróby. Nie dowodzi obalenia rzeczywistej hipotezy ani ogólnej poprawności semantic verifiera. Poprawny przypadek bazowy może zostać przyjęty wyłącznie do faktycznie wykazanego, warunkowego poziomu. Przy braku anchoru odpowiednie kontrole są NOT_PERFORMED z powodem, nie sztucznym PASS. Nie buduj uniwersalnego walidatora ani szerokiej macierzy nowych testów.

## 7. Prosty zapis bez ponownego freeze i nadpisywania PRE

Pracuj append-only: kod w wersjonowanych plikach, każda próba w nowym attempts/NNNN z faktycznym code/input identity, stdout/stderr, wynikiem i czasem lub null+UNKNOWN. Nie nadpisuj kodu ani wyników. Kolejna wersja ma nową nazwę; stara pozostaje. Jedynym plikiem dopisywanym jest ATTEMPT_LOG.jsonl, bez edycji/usuwania wcześniejszych wierszy. Jego finalny hash poda manifest.

Nie twórz osobnego mechanizmu baseline/refreeze. Wersje są fizycznie zachowane przez niezmienność. Prerejestracja powstaje raz przed science i nie jest przepisywana. **Wspólny licznik2 rund poprawek działa od pierwszego wykonania własnego narzędzia w tym runie. Każda późniejsza poprawa błędu już zapisanej własnej wersji liczy się, także w nowym narzędziu, przed pierwszym udanym POST, przed QC i w materializacji.** Nowy plik, dispatch lub nazwa etapu nie zerują licznika. Normalne pierwsze zapisanie nowego raportu nie jest naprawą; sprostowanie jego błędu nią jest. Po2 rundach ujawnij PARTIAL, bez trzeciej.

Wymagane dokumenty główne: PREFLIGHT.json, PREREGISTRATION.json, SOURCE_READS.json, EVIDENCE.json (roster, provenance, assumptions, controls i jeden typed final-status block), QC.json, REPORT.md, ATTEMPT_LOG.jsonl, MANIFEST_SHA256.csv. Do tego zapisane bufory, wyjścia decoderów i faktycznie użyte wersje narzędzi/prób. Nie generuj wielu terminali zawierających ręcznie przepisane liczniki.

Każdy nowy JSON/JSONL parsuj ściśle przed zamknięciem. Nie wpisuj wyrażeń typu liczba+opis zamiast wartości JSON. Manifest sprawdza tożsamość, a nie składnię lub science. Nie twórz narzędzi w zewnętrznym Temp; Python-B/PYTHONDONTWRITEBYTECODE, WSL czyta bufor przez/mnt/c, bez kopii do/tmp/home. Powstrzymaj rozszerzenie prac po wykryciu defektu spoza zakresu.

## 8. Terminale, zachowanie science i HARD STOP

Dozwolone wyniki lokalnego pytania: CONFIRMED_STATIC_CONDITIONAL_IN_EXAMINED_MODEL, NOT_ESTABLISHED_WITHIN_BOUND, NOT_QUALIFIED_TOOL_LIMIT, PARTIAL albo BLOCKED_PREFLIGHT/BLOCKED_TOOLING. Nie obiecuj potwierdzenia. Brak producenta w tym oknie nie jest NO_PRODUCER_ANYWHERE.

Zachowaj historyczny standing20/20 jako zapis źródłowego runu, z osobnym opisem późniejszych supersessions procesu. Nie przepisuj jego dawnego PENDING ani nie poprawiaj błędnego fresh-QC JSON. Dla nowego runu:

```ini
FIELD_SEMANTICS = UNVERIFIED_EXCEPT_SCOPED_WIDTH_AND_ADDRESS_FACTS
CURSOR_SOURCE_MEDIUM = UNKNOWN
ACTUAL_VIRTUAL_CALLEE_TARGET = NOT_ESTABLISHED_UNLESS_DIRECTLY_EVIDENCED_IN_SCOPE
ACTUAL_VIRTUAL_CALLEE_EFFECTS = NOT_ESTABLISHED
ALLOCATION_RETURN_EQUALS_INITIALIZATION_RETURN = NOT_ESTABLISHED
STATIC_BUILDING_ROLE = NOT_ESTABLISHED
MODEL_218757_TO_THIS_PARSER_INSTANCE = NOT_ESTABLISHED
MODEL_218757_TO_CMO_JOIN = NOT_ESTABLISHED
WORLD_INSTANCE_IDENTITY = NOT_ESTABLISHED
HISTORICAL_PLACEMENT = NOT_ESTABLISHED
WORLD_XYZ_RECOVERED = NO
RETROACTIVE_AUTHORIZATION = NO
CANONICAL_GATE_EFFECT = NONE
REPOSITORY_MODIFIED = NO
COMMIT_PUSH = NOT_PERFORMED
EXTERNAL_POSTAUDIT_OF_THIS_RUN = PENDING
NEXT_EXPERIMENT_AUTHORIZED = NO
NEXT_MILESTONE_AUTHORIZED = NO
HARD_STOP = YES
```

Zakazane: dalsze funkcje/callees, xref/callgraph census, B9/BRANCH39 RE, inne regiony EXE, VFS/BNT/ARK/NIF, SDK/research sieciowy, runtime i Entropia.exe jako proces, placement scan, viewer/world changes, git/repo-write/commit/push, zmiana starych pakietów. Nie otwieraj dodatkowego źródła, aby zastąpić UNKNOWN.

Po QC: drugi hash EXE jeśli rozpoczęto science, re-hash11 kopii wejść, zamknięcie logs/raportu, ścisły parse JSON, dynamiczny manifest wszystkich fizycznych plików poza samym manifestem. Pełna bijekcja, zero wykluczeń/próbek. Manifest jest ostatnim zapisem; jego SIZE/SHA i wynik read-only re-hash podaj w wiadomości terminalnej, nie dopisuj do pakietu. Wynik negatywny albo PARTIAL zachowaj uczciwie, jeśli integralność pozwala zamknąć dowody.

Zwróć: RUN_ID, LOCAL_INGRESS_RESULT, receiver/argument/K i granice dowodu, ABI assumptions, CURSOR_SOURCE_MEDIUM, FIRST_MISSING_EDGE, budżety actual/limit, decoder coverage/disagreements, wyniki4 kontrolek, QC_ORIGIN/findings, SOURCE_UNCHANGED, manifest rows/physical/SIZE/SHA, ścieżkę REPORT i powyższe standing restrictions. Następnie HARD STOP. Nie przygotowuj ani nie wykonuj automatycznie następnego micro-runu.
