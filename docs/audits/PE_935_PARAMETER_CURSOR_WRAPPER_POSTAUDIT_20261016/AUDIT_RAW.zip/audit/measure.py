"""Saved-package audit. No path obtained from evidence is ever opened externally."""
import csv, hashlib, json, re, struct
from pathlib import Path, PureWindowsPath
from datetime import datetime, timezone
BASE=Path(r'C:\Users\User\Documents\Codex\2026-10-13\files-pasted-by-the-user-wszystko')
ROOT=Path(r'D:\Eudoria_Reconstruction\99_Audits\PE_935_PARAMETER_CURSOR_UPSTREAM_WRAPPER_R1_20261016')
AUTHOR=BASE/'outputs/PARAMETER_CURSOR_UPSTREAM_WRAPPER_PROMPT_R1_20261016'
OUT=BASE/'outputs/PARAMETER_CURSOR_WRAPPER_POSTAUDIT_20261016'
OUT.mkdir(exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest().upper()
def safe(root, name):
    assert not PureWindowsPath(name).drive and not PureWindowsPath(name).root and not Path(name).is_absolute(), name
    p=(root/name).resolve()
    assert p.is_relative_to(root.resolve()), name
    return p
def read(root,name): return safe(root,name).read_bytes()
def txt(root,name): return read(root,name).decode('utf-8-sig')
def pairs(ps):
    d={}
    for k,v in ps:
        if k in d: raise ValueError('duplicate key '+k)
        d[k]=v
    return d
def strict(s): return json.loads(s,object_pairs_hook=pairs,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
def doc(root,name): return strict(txt(root,name))
def census(root):
    return {p.relative_to(root).as_posix():{'size_bytes':len(b),'sha256':sha(b)} for p in sorted(root.rglob('*')) if p.is_file() for b in [p.read_bytes()]}
def manifest(root,inv):
    rows=list(csv.DictReader(txt(root,'MANIFEST_SHA256.csv').splitlines())); names=[]; errors=[]
    for r in rows:
        n=r['relative_path'].replace('\\','/');safe(root,n);names.append(n)
        if inv.get(n)!={'size_bytes':int(r['size_bytes']),'sha256':r['sha256'].upper()}: errors.append(n)
    return {'rows':len(rows),'physical_files':len(inv),'bytes':sum(v['size_bytes'] for v in inv.values()),'identity':inv['MANIFEST_SHA256.csv'],'errors':errors,'duplicates':len(names)-len(set(names)),'unlisted':sorted(set(inv)-{'MANIFEST_SHA256.csv'}-set(names)),'missing':sorted(set(names)-set(inv))}
before=census(ROOT);abefore=census(AUTHOR)
m=manifest(ROOT,before);am=manifest(AUTHOR,abefore)
assert not any(m[k] for k in ['errors','duplicates','unlisted','missing'])
pins=doc(AUTHOR,'INPUT_PINS.json');pc=[]
for r in pins['files']:
    b=read(AUTHOR,r['relative_path']);pc.append({'file':r['relative_path'],'match':len(b)==r['size_bytes'] and sha(b)==r['sha256'].upper()})
for n,sz,h in [('INPUT_PINS.json',6186,'E6F46702F9BE6821282C40B1F1C3479E523CFDF0BB9384D547C32D8C08BE3B65'),('OPENCODE_PARAMETER_CURSOR_UPSTREAM_WRAPPER_R1.md',25252,'F0EA823C650953FAFA4D2524538332258573D49F6B2AE6A7D0879B199435F7C2')]:
    b=read(AUTHOR,n);pc.append({'file':n,'match':len(b)==sz and sha(b)==h})
assert all(r['match'] for r in pc)
json_ok=[];json_bad=[]
for n in before:
    if n.endswith(('.json','.jsonl')):
        try:
            s=txt(ROOT,n);v=[strict(x) for x in s.splitlines() if x.strip()] if n.endswith('.jsonl') else strict(s);json_ok.append(n)
        except Exception as e: json_bad.append({'file':n,'error':str(e)})
w=read(ROOT,'buffers/window_science_read1.bin');w2=read(ROOT,'buffers/window_science_read2.bin')
assert len(w)==82 and w==w2 and sha(w)=='43134E71A4C84F7F06972F9EDC3C6BDC8A29A5FCBCF27E6D95252FE5B2D30B5C'
rawheader=read(ROOT,'buffers/pe_header_first4096.bin');header=rawheader.replace(b'\r\n',b'\n')
assert len(rawheader)==4099 and len(header)==4096 and sha(header)=='636B01A25A9DE410781805D67AE1149FA64DF3D26C5C4FDE7D2D9EBCABC5A5C0'
pe=struct.unpack_from('<I',header,60)[0];assert header[:2]==b'MZ' and header[pe:pe+4]==b'PE\0\0'
machine,nsec=struct.unpack_from('<HH',header,pe+4);optsz=struct.unpack_from('<H',header,pe+20)[0];opt=pe+24;base=struct.unpack_from('<I',header,opt+28)[0];sections=[]
for i in range(nsec):
    o=opt+optsz+40*i;name=header[o:o+8].split(b'\0')[0].decode('ascii');vs,rva,rs,rp=struct.unpack_from('<IIII',header,o+8);ch=struct.unpack_from('<I',header,o+36)[0]
    sections.append(dict(name=name,virtual_size=vs,rva=rva,raw_size=rs,raw_pointer=rp,characteristics=ch))
a=[]
for l in txt(ROOT,'decode/PATH_A_SWEEP.txt').splitlines():
    p=l.split('\t')
    if len(p)>2 and re.fullmatch(r'\s*[0-9a-fA-F]+:\s*',p[0]): a.append((int(p[0].strip().rstrip(':'),16),bytes.fromhex(p[1]),' '.join(p[2:]).strip()))
roster=doc(ROOT,'decode/INSTRUCTION_ROSTER.json')['instructions'];b=doc(ROOT,'decode/PATH_B_SWEEP.json')['instructions']
assert len(a)==len(roster)==len(b)==37
targets=[];nextva=0x852a30
for ar,r,br in zip(a,roster,b):
    va=int(r['va'],16);rb=bytes.fromhex(r['raw_hex'])
    assert va==nextva==ar[0]==int(br['va'],16) and rb==ar[1]==bytes.fromhex(br['raw_hex'])==w[va-0x852a30:va-0x852a30+len(rb)] and len(rb)==r['length']==br['length']
    nextva+=len(rb);t=None
    if rb[0] in (0xe8,0xe9): t=(va+5+int.from_bytes(rb[1:],'little',signed=True))&0xffffffff
    elif rb[0]==0xeb or 0x70<=rb[0]<=0x7f:t=(va+2+int.from_bytes(rb[-1:],'little',signed=True))&0xffffffff
    if t is not None:
        operand=re.search(r'(?:0x)?([0-9a-fA-F]{6,8})\s*$',ar[2]);assert operand and int(operand[1],16)==t
        targets.append({'site':hex(va),'raw_hex':rb.hex().upper(),'target':hex(t)})
assert nextva==0x852a82 and len(targets)==7
ledgerraw=read(ROOT,'ATTEMPT_LOG.jsonl');lines=ledgerraw.splitlines(keepends=True);entries=[strict(l.decode('utf-8')) for l in lines];prefix=b'';chain=[];entrychecks=[];idchecks=[];skipped=[]
for e,l in zip(entries,lines):
    q=e['ledger_prefix'];chain.append({'attempt_id':e['attempt_id'],'match':q['size_bytes']==len(prefix) and (q['sha256'] is None if not prefix else q['sha256']==sha(prefix))});prefix+=l
    ep=doc(ROOT,'attempts/'+e['attempt_id']+'/entry.json');entrychecks.append({'attempt_id':e['attempt_id'],'semantic_match':ep==e})
    for role in ['inputs','outputs','capture_files']:
        for x in e.get(role,[]):
            n=x['path']
            if PureWindowsPath(n).is_absolute() or Path(n).is_absolute():skipped.append({'attempt_id':e['attempt_id'],'role':role,'path':n,'reason':'ABSOLUTE_EXTERNAL_PATH_NEVER_OPENED'});continue
            p=safe(ROOT,n)
            retained=None
            if not p.exists() and n.startswith('_incoming/'):
                retained='attempts/'+e['attempt_id']+'/payload_input'+Path(n).suffix;p=safe(ROOT,retained)
            if not p.exists():idchecks.append({'attempt_id':e['attempt_id'],'role':role,'path':n,'missing':True});continue
            data=p.read_bytes();idchecks.append({'attempt_id':e['attempt_id'],'role':role,'path':n,'retained_as':retained,'match':len(data)==x['size_bytes'] and sha(data)==x['sha256'],'logical_crt_inverse_match':len(data.replace(b'\r\n',b'\n'))==x['size_bytes'] and sha(data.replace(b'\r\n',b'\n'))==x['sha256'],'actual_size':len(data),'claimed_size':x['size_bytes']})
assert len(entries)==19 and all(x['match'] for x in chain) and all(x['semantic_match'] for x in entrychecks)
controls=doc(ROOT,'controls/v3/control_summary.json')
tool_checks=[{'attempt_id':e['attempt_id'],'tool':e['tool'],'match':sha(read(ROOT,e['tool']))==e['tool_sha256']} for e in entries]
assert all(x['match'] for x in tool_checks)
ct=txt(AUTHOR,'OPENCODE_PARAMETER_CURSOR_UPSTREAM_WRAPPER_R1.md').split('Nowy typed standing:',1)[1].split('```ini',1)[1].split('```',1)[0]
expected=dict(re.findall(r'^([A-Z][A-Z0-9_]+)\s*=\s*([^\r\n]+)$',ct,re.M))
ev=doc(ROOT,'EVIDENCE.json')['typed_final_status_block']
assert expected==ev and len(expected)==22
index=list(csv.DictReader(txt(ROOT,'artifact_index.csv').splitlines()));indexbad=[]
for r in index:
    n=r['relative_path'].replace('\\','/');safe(ROOT,n)
    if before.get(n)!={'size_bytes':int(r['size_bytes']),'sha256':r['sha256'].upper()}:indexbad.append(n)
result={'audit_generated_utc':datetime.now(timezone.utc).isoformat(),'source_root':str(ROOT),'source_manifest':m,'authoring_manifest':am,'pin_checks':pc,'strict_json':{'pass_count':len(json_ok),'failures':json_bad},'window':{'bytes':len(w),'identical':w==w2,'sha256':sha(w),'roster_rows':len(roster),'independent_saved_transcript_comparison':'37/37 raw+heads+length; no decoder execution','targets':targets},'header':{'disk_bytes':len(rawheader),'disk_sha256':sha(rawheader),'derived_inverse_crt_bytes':len(header),'derived_inverse_crt_sha256':sha(header),'sections':sections,'image_base':base,'machine':machine,'source':'saved damaged buffer, reversible derivative; no original read by this script'},'ledger':{'entries':len(entries),'prefix_checks':chain,'entry_semantic_checks':entrychecks,'identity_checks':idchecks,'external_absolute_paths_skipped':skipped},'artifact_index':{'rows':len(index),'changed_after_index_snapshot':indexbad},'return_mask_boundary': [{'B':v,'parser_gate':v==1,'bypass_EAX':None if v==1 else f'0x{((v-1)&0xffffff00):08X}','bypass_AL':None if v==1 else 0} for v in [0,1,2,255]],'read_budget_saved_code':{'reported_bytes':16036004,'reported_full_passes':2,'established_minimum_full_passes':3,'established_minimum_bytes':24051876,'undercount_bytes':8015872,'basis':'saved t02 explicit read then file_identity->sha256_file; t09 closing read; not current original hashing'},'this_audit_original_read_deviation':{'agent':'ingress_process_review','accidental_full_reads':3,'bytes_per_read':8015872,'total_bytes':24047616,'source_written':False,'decoder_executed':False,'used_as_evidence':False},'source_inventory_unchanged':census(ROOT)==before,'authoring_inventory_unchanged':census(AUTHOR)==abefore}
result['tool_digest_checks']=tool_checks
result['standing']={'contract_keys':len(expected),'exact_evidence_match':expected==ev,'block':expected}
result['controls_saved_summary']=controls
assert result['source_inventory_unchanged'] and result['authoring_inventory_unchanged']
(OUT/'MEASUREMENTS.json').write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'manifest':m,'json_ok':len(json_ok),'json_bad':json_bad,'identity_checks':len(idchecks),'disk_mismatches':sum(not x.get('match',False) for x in idchecks),'inverse_matches':sum(not x.get('match',False) and x.get('logical_crt_inverse_match',False) for x in idchecks),'external_skipped':len(skipped),'index_changed':indexbad,'unchanged':result['source_inventory_unchanged']},indent=2))
